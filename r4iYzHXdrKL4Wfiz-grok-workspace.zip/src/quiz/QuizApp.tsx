import { useEffect, useRef, useState, type ReactNode } from "react";
import {
  ChevronLeft,
  ChevronRight,
  ChevronUp,
  ChevronDown,
  Database,
  Download,
  Eye,
  EyeOff,
  House,
  Lock,
  Maximize2,
  Medal,
  Pause,
  Pencil,
  Play,
  Plus,
  RotateCcw,
  SlidersHorizontal,
  Timer,
  Trash2,
  Trophy,
  Upload,
  Users,
  UtensilsCrossed,
  Volume2,
  VolumeX,
} from "lucide-react";
import { playCue, unlockAudio } from "@/quiz/audio";
import {
  DEFAULT_PIN,
  SWATCHES,
  TEACHER_KEY,
  type AppData,
  type Award,
  type Group,
  type Question,
  type Round,
  type Settings,
  compressImage,
  freshData,
  importPayload,
  inkOn,
  isSafeImage,
  load,
  ranked,
  save,
  shuffle,
  uid,
} from "@/quiz/data";

type Screen = "home" | "game" | "result" | "teacher";
type Modal = "pin" | "groups" | "board" | null;
type Tab = "questions" | "groups" | "scores" | "settings" | "data";
type ConfirmState = {
  title: string;
  body: string;
  ok: string;
  danger?: boolean;
  run: () => void;
};
type QuestionDraft = { id: string | null; answer: string; alt: string; image: string };
type GroupDraft = { id: string | null; name: string; color: string };

export function QuizApp() {
  const [data, setData] = useState<AppData>(() => freshData());
  const [round, setRound] = useState<Round | null>(null);
  const [screen, setScreen] = useState<Screen>("home");
  const [teacher, setTeacher] = useState(false);
  const [hydrated, setHydrated] = useState(false);
  const [modal, setModal] = useState<Modal>(null);
  const [tab, setTab] = useState<Tab>("questions");
  const [notice, setNotice] = useState<string | null>(null);
  const [pinInput, setPinInput] = useState("");
  const [pinError, setPinError] = useState("");
  const [confirm, setConfirm] = useState<ConfirmState | null>(null);
  const [qDraft, setQDraft] = useState<QuestionDraft | null>(null);
  const [gDraft, setGDraft] = useState<GroupDraft | null>(null);
  const [brokenId, setBrokenId] = useState<string | null>(null);
  const actions = useRef({ next: () => {}, prev: () => {}, reveal: () => {} });
  const prevLeft = useRef<number | null>(null);

  useEffect(() => {
    const saved = load();
    setData(saved.data);
    setRound(saved.round);
    setTeacher(window.sessionStorage.getItem(TEACHER_KEY) === "1");
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    if (!save({ data, round })) {
      setNotice("บันทึกไม่สำเร็จ พื้นที่ในเบราว์เซอร์เต็ม ลองลบรูปที่อัปโหลดขนาดใหญ่");
    }
  }, [data, round, hydrated]);

  useEffect(() => {
    const onPointer = () => unlockAudio();
    window.addEventListener("pointerdown", onPointer);
    return () => window.removeEventListener("pointerdown", onPointer);
  }, []);

  useEffect(() => {
    if (screen !== "game" || !round?.running) return;
    const ends = Date.now() + round.timeLeft * 1000;
    const id = window.setInterval(() => {
      const left = Math.max(0, Math.ceil((ends - Date.now()) / 1000));
      setRound((current) => {
        if (!current?.running) return current;
        if (left <= 0) return { ...current, timeLeft: 0, running: false };
        if (current.timeLeft === left) return current;
        return { ...current, timeLeft: left };
      });
    }, 200);
    return () => window.clearInterval(id);
  }, [screen, round?.running, round?.index]);

  useEffect(() => {
    if (!round) return;
    const previous = prevLeft.current;
    prevLeft.current = round.timeLeft;
    if (previous !== null && previous > 0 && round.timeLeft === 0 && screen === "game") {
      playCue("timeout", data.settings.sound);
    }
  }, [round, screen, data.settings.sound]);

  const question = round
    ? data.questions.find((item) => item.id === round.order[round.index]) ?? null
    : null;
  const award = question && round ? round.awards[question.id] : undefined;
  const canResume = Boolean(round?.active && round.index < round.order.length);

  function goHome() {
    setRound((current) => (current ? { ...current, running: false } : current));
    setModal(null);
    setScreen("home");
  }

  function startGame(resetScores: boolean) {
    if (!data.questions.length) {
      setNotice("ยังไม่มีคำถาม เข้าโหมดครูเพื่อเพิ่มรูปและชื่ออาหาร");
      return;
    }
    playCue("start", data.settings.sound);
    const ids = data.questions.map((item) => item.id);
    setData((current) =>
      resetScores
        ? { ...current, groups: current.groups.map((group) => ({ ...group, score: 0 })) }
        : current,
    );
    setRound({
      order: data.settings.randomize ? shuffle(ids) : ids,
      index: 0,
      awards: {},
      revealed: false,
      timeLeft: data.settings.timer,
      running: true,
      active: true,
    });
    setBrokenId(null);
    setScreen("game");
  }

  function resume() {
    if (!round?.active) return;
    const currentId = round.order[round.index];
    const already = Boolean(currentId && round.awards[currentId]);
    setRound({
      ...round,
      running: round.timeLeft > 0 && !already && !round.revealed,
    });
    setScreen("game");
  }

  function reveal() {
    setRound((current) => {
      if (!current) return current;
      const showing = !current.revealed;
      return { ...current, revealed: showing, running: showing ? false : current.running };
    });
  }

  function next() {
    if (!round) return;
    const index = round.index + 1;
    if (index >= round.order.length) {
      setRound({ ...round, index, active: false, running: false, revealed: false });
      setScreen("result");
      return;
    }
    const id = round.order[index];
    const already = Boolean(round.awards[id]);
    setRound({
      ...round,
      index,
      revealed: already,
      running: !already,
      timeLeft: data.settings.timer,
    });
    setBrokenId(null);
  }

  function prev() {
    setRound((current) => {
      if (!current || current.index <= 0) return current;
      const index = current.index - 1;
      const id = current.order[index];
      const already = Boolean(current.awards[id]);
      return {
        ...current,
        index,
        revealed: already,
        running: !already,
        timeLeft: data.settings.timer,
      };
    });
    setBrokenId(null);
  }

  actions.current = { next, prev, reveal };

  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      if (event.key === "Escape") {
        setModal(null);
        setConfirm(null);
        setQDraft(null);
        setGDraft(null);
        return;
      }
      const target = event.target as HTMLElement | null;
      const typing = Boolean(
        target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.isContentEditable),
      );
      if (typing || screen !== "game" || modal || confirm || qDraft || gDraft) return;
      if (event.key === "ArrowRight") {
        event.preventDefault();
        actions.current.next();
      } else if (event.key === "ArrowLeft") {
        event.preventDefault();
        actions.current.prev();
      } else if (event.key === " ") {
        event.preventDefault();
        actions.current.reveal();
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [screen, modal, confirm, qDraft, gDraft]);

  function givePoints(groupId: string) {
    if (!round || !question || round.awards[question.id]) return;
    const points = data.settings.pointsPerQ;
    const given: Award = { groupId, points };
    setRound({
      ...round,
      revealed: true,
      running: false,
      awards: { ...round.awards, [question.id]: given },
    });
    setData((current) => ({
      ...current,
      groups: current.groups.map((group) =>
        group.id === groupId ? { ...group, score: group.score + points } : group,
      ),
    }));
    playCue("correct", data.settings.sound);
  }

  function undoPoints() {
    if (!round || !question) return;
    const given = round.awards[question.id];
    if (!given) return;
    const awards = { ...round.awards };
    delete awards[question.id];
    setRound({ ...round, awards });
    setData((current) => ({
      ...current,
      groups: current.groups.map((group) =>
        group.id === given.groupId
          ? { ...group, score: Math.max(0, group.score - given.points) }
          : group,
      ),
    }));
  }

  function toggleTimer() {
    setRound((current) => {
      if (!current || current.timeLeft <= 0) return current;
      return { ...current, running: !current.running };
    });
  }

  function verifyPin() {
    if (pinInput === data.settings.pin) {
      setTeacher(true);
      window.sessionStorage.setItem(TEACHER_KEY, "1");
      setPinInput("");
      setPinError("");
      setModal(null);
      setScreen("teacher");
      return;
    }
    setPinError("รหัสไม่ถูกต้อง");
  }

  function logout() {
    window.sessionStorage.removeItem(TEACHER_KEY);
    setTeacher(false);
    setScreen("home");
  }

  function ask(nextConfirm: ConfirmState) {
    setConfirm(nextConfirm);
  }

  const title = data.settings.gameTitle || "Food Picture Quiz";

  return (
    <>
      {screen === "home" ? (
        <Home
          title={title}
          canResume={canResume}
          onStart={() => startGame(false)}
          onResetStart={() =>
            ask({
              title: "เริ่มรอบใหม่และล้างคะแนน",
              body: "คะแนนทุกกลุ่มจะกลับเป็น 0 แล้วเริ่มข้อแรกใหม่",
              ok: "ล้างคะแนนแล้วเริ่ม",
              danger: true,
              run: () => startGame(true),
            })
          }
          onResume={resume}
          onGroups={() => setModal("groups")}
          onBoard={() => setModal("board")}
          onTeacher={() => {
            if (teacher) setScreen("teacher");
            else {
              setPinError("");
              setModal("pin");
            }
          }}
        />
      ) : null}

      {screen === "game" && round ? (
        <Game
          title={title}
          round={round}
          question={question}
          groups={data.groups}
          award={award}
          points={data.settings.pointsPerQ}
          broken={brokenId === question?.id}
          onBroken={() => question && setBrokenId(question.id)}
          onHome={goHome}
          onPrev={prev}
          onNext={next}
          onReveal={reveal}
          onToggleTimer={toggleTimer}
          onAward={givePoints}
          onUndo={undoPoints}
        />
      ) : null}

      {screen === "result" ? (
        <Result
          groups={data.groups}
          onAgain={() => startGame(false)}
          onReset={() => startGame(true)}
          onHome={goHome}
        />
      ) : null}

      {screen === "teacher" && teacher ? (
        <Teacher
          data={data}
          tab={tab}
          setTab={setTab}
          onLogout={logout}
          onQuestions={(questions) => setData((current) => ({ ...current, questions }))}
          onGroups={(groups) => setData((current) => ({ ...current, groups }))}
          onSettings={(settings) => setData((current) => ({ ...current, settings }))}
          onReplace={(next) => {
            setData(next);
            setRound(null);
          }}
          onReset={() => {
            setData(freshData());
            setRound(null);
            setNotice("คืนค่าเริ่มต้นแล้ว");
          }}
          ask={ask}
          openQuestion={setQDraft}
          openGroup={setGDraft}
          setNotice={setNotice}
        />
      ) : null}

      {modal === "pin" ? (
        <Modal title="โหมดครู" onClose={() => setModal(null)}>
          <p className="text-muted">ใช้สำหรับจัดการคำถาม กลุ่ม และคะแนนบนเครื่องนี้</p>
          <form
            className="mt-4 grid gap-3"
            onSubmit={(event) => {
              event.preventDefault();
              verifyPin();
            }}
          >
            <label className="grid gap-1 font-semibold" htmlFor="pin">
              รหัสครู
              <input
                id="pin"
                className="field"
                type="password"
                autoFocus
                value={pinInput}
                onChange={(event) => setPinInput(event.target.value)}
              />
            </label>
            {pinError ? <p className="text-chili">{pinError}</p> : null}
            <button className="btn btn-chili" type="submit">เข้าสู่โหมดครู</button>
          </form>
        </Modal>
      ) : null}

      {modal === "groups" ? (
        <Modal title="กลุ่มผู้เล่น" onClose={() => setModal(null)}>
          <GroupList groups={data.groups} />
        </Modal>
      ) : null}

      {modal === "board" ? (
        <Modal title="ตารางคะแนน" onClose={() => setModal(null)}>
          <Board groups={data.groups} />
        </Modal>
      ) : null}

      {qDraft ? (
        <QuestionModal
          draft={qDraft}
          setDraft={setQDraft}
          onClose={() => setQDraft(null)}
          onSave={() => {
            if (!qDraft.answer.trim() || !isSafeImage(qDraft.image)) {
              setNotice("ใส่ชื่ออาหารและรูปที่ใช้งานได้");
              return;
            }
            setData((current) => {
              const next = qDraft.id
                ? current.questions.map((item) =>
                    item.id === qDraft.id
                      ? { ...item, answer: qDraft.answer.trim(), alt: qDraft.alt.trim(), image: qDraft.image }
                      : item,
                  )
                : [
                    ...current.questions,
                    { id: uid("q"), answer: qDraft.answer.trim(), alt: qDraft.alt.trim(), image: qDraft.image },
                  ];
              return { ...current, questions: next };
            });
            setQDraft(null);
          }}
          setNotice={setNotice}
        />
      ) : null}

      {gDraft ? (
        <Modal title={gDraft.id ? "แก้ไขกลุ่ม" : "เพิ่มกลุ่ม"} onClose={() => setGDraft(null)}>
          <form
            className="grid gap-3"
            onSubmit={(event) => {
              event.preventDefault();
              const name = gDraft.name.trim();
              if (!name) return;
              setData((current) => ({
                ...current,
                groups: gDraft.id
                  ? current.groups.map((group) =>
                      group.id === gDraft.id ? { ...group, name, color: gDraft.color } : group,
                    )
                  : [...current.groups, { id: uid("g"), name, color: gDraft.color, score: 0 }],
              }));
              setGDraft(null);
            }}
          >
            <label className="grid gap-1 font-semibold">
              ชื่อกลุ่ม
              <input
                className="field"
                value={gDraft.name}
                onChange={(event) => setGDraft({ ...gDraft, name: event.target.value })}
              />
            </label>
            <div className="grid gap-2">
              <span className="font-semibold">สีกลุ่ม</span>
              <div className="flex flex-wrap gap-2">
                {SWATCHES.map((color) => (
                  <button
                    key={color}
                    type="button"
                    aria-label={color}
                    className="size-11 rounded-full"
                    style={{
                      background: color,
                      boxShadow: gDraft.color === color ? "0 0 0 3px #241c16" : "inset 0 0 0 1px #e3d6c6",
                    }}
                    onClick={() => setGDraft({ ...gDraft, color })}
                  />
                ))}
                <input
                  aria-label="เลือกสีเอง"
                  className="size-11"
                  type="color"
                  value={gDraft.color}
                  onChange={(event) => setGDraft({ ...gDraft, color: event.target.value })}
                />
              </div>
            </div>
            <button className="btn btn-chili" type="submit">บันทึกกลุ่ม</button>
          </form>
        </Modal>
      ) : null}

      {confirm ? (
        <Modal title={confirm.title} onClose={() => setConfirm(null)}>
          <p>{confirm.body}</p>
          <div className="mt-4 flex flex-wrap gap-2">
            <button className="btn btn-line" type="button" onClick={() => setConfirm(null)}>ยกเลิก</button>
            <button
              className={confirm.danger ? "btn btn-chili" : "btn btn-ink"}
              type="button"
              onClick={() => {
                confirm.run();
                setConfirm(null);
              }}
            >
              {confirm.ok}
            </button>
          </div>
        </Modal>
      ) : null}

      {notice ? (
        <div className="fixed inset-x-0 bottom-4 z-50 mx-auto flex w-[min(92vw,32rem)] items-center justify-between gap-3 rounded-card bg-ink px-4 py-3 text-on-night shadow-lg">
          <p>{notice}</p>
          <button className="btn btn-chili" type="button" onClick={() => setNotice(null)}>ปิด</button>
        </div>
      ) : null}
    </>
  );
}

function Home({
  title,
  canResume,
  onStart,
  onResetStart,
  onResume,
  onGroups,
  onBoard,
  onTeacher,
}: {
  title: string;
  canResume: boolean;
  onStart: () => void;
  onResetStart: () => void;
  onResume: () => void;
  onGroups: () => void;
  onBoard: () => void;
  onTeacher: () => void;
}) {
  const mosaic = ["/food/tom-yum.jpg", "/food/pad-thai.jpg", "/food/mango-sticky.jpg", "/food/sushi.jpg"];
  return (
    <main className="mx-auto grid min-h-dvh max-w-6xl items-center gap-8 px-4 py-8 md:grid-cols-2 md:px-8">
      <section>
        <p className="font-semibold text-chili">เกมห้องเรียน</p>
        <h1 className="mt-2 font-display text-5xl leading-none text-ink md:text-6xl">{title}</h1>
        <p className="mt-4 max-w-md text-lg text-muted">
          เปิดภาพอาหารบนจอ ให้นักเรียนทายชื่อ แล้วให้คะแนนกลุ่มที่ได้คำตอบ
        </p>
        <div className="mt-6 grid max-w-sm gap-3">
          <button className="btn btn-chili" type="button" onClick={onStart}>
            <Play className="size-5" aria-hidden="true" /> เริ่มเกม
          </button>
          {canResume ? (
            <button className="btn btn-ink" type="button" onClick={onResume}>เล่นต่อจากข้อที่ค้าง</button>
          ) : null}
          <button className="btn btn-line" type="button" onClick={onGroups}>
            <Users className="size-5" aria-hidden="true" /> กลุ่มผู้เล่น
          </button>
          <button className="btn btn-line" type="button" onClick={onBoard}>
            <Trophy className="size-5" aria-hidden="true" /> ตารางคะแนน
          </button>
          <button className="btn btn-line" type="button" onClick={onResetStart}>
            <RotateCcw className="size-5" aria-hidden="true" /> เริ่มใหม่และล้างคะแนน
          </button>
          <button className="btn btn-line" type="button" onClick={onTeacher}>
            <Lock className="size-5" aria-hidden="true" /> โหมดครู
          </button>
        </div>
      </section>
      <section className="grid grid-cols-2 gap-3" aria-hidden="true">
        {mosaic.map((src) => (
          <img key={src} src={src} alt="" className="aspect-square w-full rounded-card object-cover" />
        ))}
      </section>
    </main>
  );
}

function Game({
  title,
  round,
  question,
  groups,
  award,
  points,
  broken,
  onBroken,
  onHome,
  onPrev,
  onNext,
  onReveal,
  onToggleTimer,
  onAward,
  onUndo,
}: {
  title: string;
  round: Round;
  question: Question | null;
  groups: Group[];
  award?: Award;
  points: number;
  broken: boolean;
  onBroken: () => void;
  onHome: () => void;
  onPrev: () => void;
  onNext: () => void;
  onReveal: () => void;
  onToggleTimer: () => void;
  onAward: (groupId: string) => void;
  onUndo: () => void;
}) {
  const awardedGroup = award ? groups.find((group) => group.id === award.groupId) : undefined;
  const hot = round.timeLeft <= 5;
  return (
    <main className="flex min-h-dvh flex-col gap-3 p-3 md:h-dvh md:overflow-hidden">
      <header className="flex flex-wrap items-center gap-3 rounded-card bg-surface px-3 py-2">
        <button className="btn btn-line" type="button" onClick={onHome}>
          <House className="size-5" aria-hidden="true" /> หน้าแรก
        </button>
        <p className="font-display text-xl">
          ข้อ {Math.min(round.index + 1, round.order.length)}/{round.order.length}
        </p>
        <h1 className="min-w-0 flex-1 truncate text-center font-display text-2xl">{title}</h1>
        <button
          className={`btn ${hot ? "btn-chili timer-hot" : "btn-line"}`}
          type="button"
          onClick={onToggleTimer}
        >
          <Timer className="size-5" aria-hidden="true" />
          {round.timeLeft} วิ
          {round.running ? <Pause className="size-4" aria-hidden="true" /> : <Play className="size-4" aria-hidden="true" />}
        </button>
        <button
          className="btn btn-line"
          type="button"
          aria-label="เต็มหน้าจอ"
          onClick={() => {
            if (!document.fullscreenElement) {
              void document.documentElement.requestFullscreen().catch(() => {});
            } else {
              void document.exitFullscreen?.();
            }
          }}
        >
          <Maximize2 className="size-5" aria-hidden="true" />
        </button>
      </header>

      <div className="relative min-h-72 flex-1 overflow-hidden rounded-card bg-night">
        {question && !broken ? (
          <img
            key={question.id}
            src={question.image}
            alt="ภาพอาหารสำหรับทาย"
            className="h-full w-full object-contain"
            onError={onBroken}
          />
        ) : (
          <div className="grid h-full place-items-center px-6 text-center text-on-night">
            <p className="font-display text-3xl">{question ? "โหลดภาพนี้ไม่ได้" : "คำถามข้อนี้ไม่มีแล้ว"}</p>
          </div>
        )}
        {round.revealed && question ? (
          <div className="absolute inset-x-0 bottom-0 bg-leaf px-4 py-3 text-center text-on-leaf">
            <p className="font-display text-4xl leading-none">{question.answer}</p>
            {question.alt ? <p className="mt-1">รับคำตอบสำรอง: {question.alt}</p> : null}
          </div>
        ) : null}
      </div>

      <section className="rounded-card bg-surface p-3">
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
          <p>
            กลุ่มที่ได้คะแนนข้อนี้:{" "}
            <strong style={{ color: awardedGroup?.color }}>
              {awardedGroup ? `${awardedGroup.name} (+${award?.points})` : "ยังไม่ได้ให้"}
            </strong>
          </p>
          <div className="flex flex-wrap gap-2">
            <button className="btn btn-line" type="button" onClick={onPrev} disabled={round.index === 0}>
              <ChevronLeft className="size-5" aria-hidden="true" /> ก่อนหน้า
            </button>
            <button className="btn btn-ink" type="button" onClick={onReveal}>
              {round.revealed ? <EyeOff className="size-5" aria-hidden="true" /> : <Eye className="size-5" aria-hidden="true" />}
              {round.revealed ? "ซ่อนเฉลย" : "เฉลย"}
            </button>
            <button className="btn btn-chili" type="button" onClick={onNext}>
              {round.index + 1 >= round.order.length ? "สรุปผล" : "ข้อถัดไป"}
              <ChevronRight className="size-5" aria-hidden="true" />
            </button>
          </div>
        </div>
        {round.revealed ? (
          <div className="grid gap-2 sm:grid-cols-2">
            {groups.length ? (
              groups.map((group) => {
                const selected = award?.groupId === group.id;
                return (
                  <button
                    key={group.id}
                    type="button"
                    className="btn h-auto whitespace-normal px-3 py-2 text-center"
                    disabled={Boolean(award) && !selected}
                    style={{ background: group.color, color: inkOn(group.color) }}
                    onClick={() => (selected ? onUndo() : onAward(group.id))}
                  >
                    {selected ? `ยกเลิกคะแนน ${group.name}` : `${group.name} +${points}`}
                  </button>
                );
              })
            ) : (
              <p className="text-muted">ยังไม่มีกลุ่ม เพิ่มได้ในโหมดครู</p>
            )}
          </div>
        ) : (
          <p className="text-sm text-muted">ลูกศรซ้าย/ขวาเปลี่ยนข้อ · Space เฉลย · กดเวลาเพื่อหยุดนาฬิกา</p>
        )}
      </section>

      <section className="flex gap-2 overflow-x-auto pb-1">
        {groups.map((group) => (
          <div
            key={group.id}
            className="flex min-w-36 items-center justify-between gap-3 rounded-2xl bg-surface px-3 py-2"
            style={{ boxShadow: `inset 4px 0 0 ${group.color}` }}
          >
            <span className="truncate font-semibold">{group.name}</span>
            <span>{group.score}</span>
          </div>
        ))}
      </section>
    </main>
  );
}

function Result({
  groups,
  onAgain,
  onReset,
  onHome,
}: {
  groups: Group[];
  onAgain: () => void;
  onReset: () => void;
  onHome: () => void;
}) {
  const rows = ranked(groups);
  const slots = [rows[1], rows[0], rows[2]];
  return (
    <main className="flex min-h-dvh flex-col items-center bg-night px-4 py-8 text-on-night">
      <Medal className="size-10 text-gold" aria-hidden="true" />
      <h1 className="mt-2 font-display text-5xl">สรุปผล</h1>
      <div className="mt-8 flex items-end justify-center gap-3">
        {slots.map((group, index) =>
          group ? (
            <div
              key={group.id}
              className={`grid w-28 place-items-end rounded-t-card px-2 py-3 text-center text-ink sm:w-36 ${
                index === 1 ? "h-44 bg-gold" : index === 0 ? "h-32 bg-line" : "h-24 bg-chili-soft"
              }`}
            >
              <div>
                <p className="text-sm">อันดับ {group.rank}</p>
                <p className="font-display text-xl leading-tight">{group.name}</p>
                <p className="font-semibold">{group.score}</p>
              </div>
            </div>
          ) : (
            <div key={index} className="w-28 sm:w-36" />
          ),
        )}
      </div>
      <ol className="mt-8 w-full max-w-lg">
        {rows.map((group) => (
          <li key={group.id} className="flex items-center gap-3 border-b border-line/30 py-3">
            <span className="w-8 font-display text-2xl">{group.rank}</span>
            <span className="size-3 rounded-full" style={{ background: group.color }} />
            <span className="flex-1">{group.name}</span>
            <span className="font-semibold">{group.score} คะแนน</span>
          </li>
        ))}
      </ol>
      <div className="mt-8 flex flex-wrap justify-center gap-2">
        <button className="btn btn-chili" type="button" onClick={onAgain}>เล่นอีกรอบ (เก็บคะแนน)</button>
        <button className="btn btn-gold" type="button" onClick={onReset}>ล้างคะแนนแล้วเล่นใหม่</button>
        <button className="btn btn-line" type="button" onClick={onHome}>หน้าแรก</button>
      </div>
    </main>
  );
}

function Teacher({
  data,
  tab,
  setTab,
  onLogout,
  onQuestions,
  onGroups,
  onSettings,
  onReplace,
  onReset,
  ask,
  openQuestion,
  openGroup,
  setNotice,
}: {
  data: AppData;
  tab: Tab;
  setTab: (tab: Tab) => void;
  onLogout: () => void;
  onQuestions: (questions: Question[]) => void;
  onGroups: (groups: Group[]) => void;
  onSettings: (settings: Settings) => void;
  onReplace: (data: AppData) => void;
  onReset: () => void;
  ask: (confirm: ConfirmState) => void;
  openQuestion: (draft: QuestionDraft) => void;
  openGroup: (draft: GroupDraft) => void;
  setNotice: (message: string) => void;
}) {
  const tabs: { id: Tab; label: string; icon: typeof UtensilsCrossed }[] = [
    { id: "questions", label: "คำถาม", icon: UtensilsCrossed },
    { id: "groups", label: "กลุ่ม", icon: Users },
    { id: "scores", label: "คะแนน", icon: Trophy },
    { id: "settings", label: "ตั้งค่า", icon: SlidersHorizontal },
    { id: "data", label: "ข้อมูล", icon: Database },
  ];
  return (
    <main className="min-h-dvh bg-paper">
      <header className="flex items-center justify-between gap-3 border-b border-line bg-surface px-4 py-3">
        <h1 className="font-display text-3xl">โหมดครู</h1>
        <button className="btn btn-chili" type="button" onClick={onLogout}>ออกจากโหมดครู</button>
      </header>
      <div className="md:grid md:grid-cols-[14rem_1fr]">
        <nav className="flex gap-2 overflow-x-auto border-b border-line bg-surface p-2 md:flex-col md:border-r md:border-b-0">
          {tabs.map((item) => (
            <button
              key={item.id}
              type="button"
              className={`btn justify-start ${tab === item.id ? "btn-ink" : "btn-line"}`}
              onClick={() => setTab(item.id)}
            >
              <item.icon className="size-5" aria-hidden="true" /> {item.label}
            </button>
          ))}
        </nav>
        <section className="p-4">
          {tab === "questions" ? (
            <div>
              <button
                className="btn btn-chili"
                type="button"
                onClick={() => openQuestion({ id: null, answer: "", alt: "", image: "" })}
              >
                <Plus className="size-5" aria-hidden="true" /> เพิ่มคำถาม
              </button>
              <div className="mt-4 overflow-x-auto rounded-card bg-surface">
                <table className="w-full min-w-[40rem] text-left">
                  <thead className="text-muted">
                    <tr>
                      <th className="p-3">ข้อ</th>
                      <th className="p-3">ภาพ</th>
                      <th className="p-3">เฉลย</th>
                      <th className="p-3">สำรอง</th>
                      <th className="p-3">จัดการ</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.questions.map((question, index) => (
                      <tr key={question.id} className="border-t border-line">
                        <td className="p-3">{index + 1}</td>
                        <td className="p-3">
                          <img src={question.image} alt="" className="h-14 w-20 rounded-xl bg-paper object-contain" />
                        </td>
                        <td className="p-3 font-semibold">{question.answer}</td>
                        <td className="p-3 text-muted">{question.alt || "-"}</td>
                        <td className="p-3">
                          <div className="flex flex-wrap gap-1">
                            <IconButton label="เลื่อนขึ้น" onClick={() => move(data.questions, index, -1, onQuestions)}>
                              <ChevronUp className="size-4" />
                            </IconButton>
                            <IconButton label="เลื่อนลง" onClick={() => move(data.questions, index, 1, onQuestions)}>
                              <ChevronDown className="size-4" />
                            </IconButton>
                            <IconButton
                              label="แก้ไข"
                              onClick={() =>
                                openQuestion({
                                  id: question.id,
                                  answer: question.answer,
                                  alt: question.alt,
                                  image: question.image,
                                })
                              }
                            >
                              <Pencil className="size-4" />
                            </IconButton>
                            <IconButton
                              label="ลบ"
                              onClick={() =>
                                ask({
                                  title: "ลบคำถาม",
                                  body: `ลบ “${question.answer}” ออกจากชุดคำถาม`,
                                  ok: "ลบ",
                                  danger: true,
                                  run: () => onQuestions(data.questions.filter((item) => item.id !== question.id)),
                                })
                              }
                            >
                              <Trash2 className="size-4" />
                            </IconButton>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ) : null}

          {tab === "groups" ? (
            <div>
              <button
                className="btn btn-chili"
                type="button"
                onClick={() => openGroup({ id: null, name: "", color: SWATCHES[data.groups.length % SWATCHES.length] })}
              >
                <Plus className="size-5" aria-hidden="true" /> เพิ่มกลุ่ม
              </button>
              <ul className="mt-4 grid gap-2">
                {data.groups.map((group) => (
                  <li key={group.id} className="flex items-center gap-3 rounded-card bg-surface p-3">
                    <span className="size-6 rounded-full" style={{ background: group.color }} />
                    <span className="flex-1 font-semibold">{group.name}</span>
                    <span>{group.score} คะแนน</span>
                    <IconButton label="แก้ไขกลุ่ม" onClick={() => openGroup({ id: group.id, name: group.name, color: group.color })}>
                      <Pencil className="size-4" />
                    </IconButton>
                    <IconButton
                      label="ลบกลุ่ม"
                      onClick={() =>
                        ask({
                          title: "ลบกลุ่ม",
                          body: `ลบ ${group.name} และคะแนนของกลุ่มนี้`,
                          ok: "ลบ",
                          danger: true,
                          run: () => onGroups(data.groups.filter((item) => item.id !== group.id)),
                        })
                      }
                    >
                      <Trash2 className="size-4" />
                    </IconButton>
                  </li>
                ))}
              </ul>
            </div>
          ) : null}

          {tab === "scores" ? (
            <div className="grid gap-3">
              <button
                className="btn btn-chili w-fit"
                type="button"
                onClick={() =>
                  ask({
                    title: "รีเซ็ตคะแนน",
                    body: "คะแนนทุกกลุ่มจะเป็น 0 แต่คำถามและชื่อกลุ่มยังอยู่",
                    ok: "รีเซ็ต",
                    danger: true,
                    run: () => onGroups(data.groups.map((group) => ({ ...group, score: 0 }))),
                  })
                }
              >
                <RotateCcw className="size-5" aria-hidden="true" /> รีเซ็ตคะแนนทั้งหมด
              </button>
              {data.groups.map((group) => (
                <div key={group.id} className="flex flex-wrap items-center gap-2 rounded-card bg-surface p-3">
                  <span className="size-4 rounded-full" style={{ background: group.color }} />
                  <strong className="flex-1">{group.name}</strong>
                  <span className="w-16 text-right font-display text-2xl">{group.score}</span>
                  <button className="btn btn-leaf" type="button" onClick={() => bump(group.id, data.settings.pointsPerQ, data.groups, onGroups)}>
                    +{data.settings.pointsPerQ}
                  </button>
                  <button className="btn btn-line" type="button" onClick={() => bump(group.id, -data.settings.pointsPerQ, data.groups, onGroups)}>
                    -{data.settings.pointsPerQ}
                  </button>
                </div>
              ))}
            </div>
          ) : null}

          {tab === "settings" ? (
            <SettingsForm settings={data.settings} onSave={onSettings} setNotice={setNotice} />
          ) : null}

          {tab === "data" ? (
            <DataTools
              data={data}
              onReplace={onReplace}
              onReset={() =>
                ask({
                  title: "คืนค่าเริ่มต้น",
                  body: "คำถาม กลุ่ม คะแนน และการตั้งค่าจะกลับเป็นชุดอาหาร 20 ข้อ รหัสครูกลับเป็นค่าเดิม",
                  ok: "คืนค่า",
                  danger: true,
                  run: onReset,
                })
              }
              setNotice={setNotice}
            />
          ) : null}
        </section>
      </div>
    </main>
  );
}

function SettingsForm({
  settings,
  onSave,
  setNotice,
}: {
  settings: Settings;
  onSave: (settings: Settings) => void;
  setNotice: (message: string) => void;
}) {
  const [draft, setDraft] = useState(settings);
  useEffect(() => setDraft(settings), [settings]);
  return (
    <form
      className="grid max-w-lg gap-3"
      onSubmit={(event) => {
        event.preventDefault();
        const timer = Number(draft.timer);
        const points = Number(draft.pointsPerQ);
        if (!draft.gameTitle.trim() || !draft.pin.trim() || draft.pin.trim().length < 4) {
          setNotice("ตั้งชื่อเกมและรหัสครูอย่างน้อย 4 ตัว");
          return;
        }
        if (!Number.isFinite(timer) || timer < 5 || timer > 3600 || !Number.isFinite(points) || points < 0) {
          setNotice("เวลาต้องอยู่ระหว่าง 5–3600 วินาที และคะแนนต้องไม่ติดลบ");
          return;
        }
        onSave({
          ...draft,
          gameTitle: draft.gameTitle.trim(),
          pin: draft.pin.trim(),
          timer: Math.round(timer),
          pointsPerQ: Math.round(points),
        });
        setNotice("บันทึกการตั้งค่าแล้ว");
      }}
    >
      <label className="grid gap-1 font-semibold">
        ชื่อเกม
        <input className="field" value={draft.gameTitle} onChange={(event) => setDraft({ ...draft, gameTitle: event.target.value })} />
      </label>
      <label className="grid gap-1 font-semibold">
        เวลาต่อข้อ (วินาที)
        <input className="field" type="number" min={5} max={3600} value={draft.timer} onChange={(event) => setDraft({ ...draft, timer: Number(event.target.value) })} />
      </label>
      <label className="grid gap-1 font-semibold">
        คะแนนต่อข้อ
        <input className="field" type="number" min={0} value={draft.pointsPerQ} onChange={(event) => setDraft({ ...draft, pointsPerQ: Number(event.target.value) })} />
      </label>
      <label className="grid gap-1 font-semibold">
        รหัสครู
        <input className="field" value={draft.pin} onChange={(event) => setDraft({ ...draft, pin: event.target.value })} />
      </label>
      <label className="flex items-center gap-2">
        <input type="checkbox" checked={draft.randomize} onChange={(event) => setDraft({ ...draft, randomize: event.target.checked })} />
        สุ่มลำดับคำถามเมื่อเริ่มเกม
      </label>
      <label className="flex items-center gap-2">
        <input type="checkbox" checked={draft.sound} onChange={(event) => setDraft({ ...draft, sound: event.target.checked })} />
        {draft.sound ? <Volume2 className="size-5" aria-hidden="true" /> : <VolumeX className="size-5" aria-hidden="true" />}
        เสียงเอฟเฟกต์
      </label>
      <button className="btn btn-chili w-fit" type="submit">บันทึกการตั้งค่า</button>
      <p className="text-sm text-muted">รหัสเริ่มต้นคือ {DEFAULT_PIN} เปลี่ยนได้จากช่องด้านบน</p>
    </form>
  );
}

function DataTools({
  data,
  onReplace,
  onReset,
  setNotice,
}: {
  data: AppData;
  onReplace: (data: AppData) => void;
  onReset: () => void;
  setNotice: (message: string) => void;
}) {
  return (
    <div className="grid max-w-lg gap-3">
      <p className="text-muted">สำรองคำถาม กลุ่ม และคะแนนเป็นไฟล์ แล้วนำเข้าบนเครื่องอื่นได้</p>
      <button
        className="btn btn-ink w-fit"
        type="button"
        onClick={() => {
          const blob = new Blob([JSON.stringify({ data }, null, 2)], { type: "application/json" });
          const url = URL.createObjectURL(blob);
          const link = document.createElement("a");
          link.href = url;
          link.download = "food-picture-quiz.json";
          link.click();
          URL.revokeObjectURL(url);
        }}
      >
        <Download className="size-5" aria-hidden="true" /> ส่งออก JSON
      </button>
      <label className="btn btn-line w-fit">
        <Upload className="size-5" aria-hidden="true" /> นำเข้า JSON
        <input
          className="sr-only"
          type="file"
          accept="application/json,.json"
          onChange={(event) => {
            const file = event.target.files?.[0];
            event.target.value = "";
            if (!file) return;
            const reader = new FileReader();
            reader.onload = () => {
              try {
                const next = importPayload(JSON.parse(String(reader.result)));
                if (!next) {
                  setNotice("ไฟล์นี้ไม่มีคำถามหรือกลุ่มที่ใช้งานได้");
                  return;
                }
                onReplace(next);
                setNotice("นำเข้าข้อมูลแล้ว");
              } catch {
                setNotice("อ่านไฟล์ JSON ไม่ได้");
              }
            };
            reader.readAsText(file);
          }}
        />
      </label>
      <button className="btn btn-chili w-fit" type="button" onClick={onReset}>
        <RotateCcw className="size-5" aria-hidden="true" /> คืนค่าเริ่มต้นทั้งหมด
      </button>
    </div>
  );
}

function QuestionModal({
  draft,
  setDraft,
  onClose,
  onSave,
  setNotice,
}: {
  draft: QuestionDraft;
  setDraft: (draft: QuestionDraft) => void;
  onClose: () => void;
  onSave: () => void;
  setNotice: (message: string) => void;
}) {
  const preview = draft.image;
  return (
    <Modal title={draft.id ? "แก้ไขคำถาม" : "เพิ่มคำถาม"} onClose={onClose}>
      <form
        className="grid gap-3"
        onSubmit={(event) => {
          event.preventDefault();
          onSave();
        }}
      >
        <label className="grid gap-1 font-semibold">
          ชื่ออาหาร
          <input className="field" value={draft.answer} onChange={(event) => setDraft({ ...draft, answer: event.target.value })} />
        </label>
        <label className="grid gap-1 font-semibold">
          คำตอบสำรอง คั่นด้วยจุลภาค
          <input className="field" value={draft.alt} onChange={(event) => setDraft({ ...draft, alt: event.target.value })} />
        </label>
        <label className="grid gap-1 font-semibold">
          อัปโหลดรูป
          <input
            className="field"
            type="file"
            accept="image/*"
            onChange={(event) => {
              const file = event.target.files?.[0];
              if (!file) return;
              compressImage(file)
                .then((image) => setDraft({ ...draft, image }))
                .catch((error: Error) => setNotice(error.message));
            }}
          />
        </label>
        <label className="grid gap-1 font-semibold">
          หรือวางลิงก์รูป
          <input
            className="field"
            value={draft.image.startsWith("data:") ? "" : draft.image}
            placeholder="https://"
            onChange={(event) => setDraft({ ...draft, image: event.target.value.trim() })}
          />
        </label>
        {preview ? <img src={preview} alt="" className="max-h-40 rounded-card object-contain" /> : null}
        <button className="btn btn-chili" type="submit">บันทึกคำถาม</button>
      </form>
    </Modal>
  );
}

function Modal({ title, onClose, children }: { title: string; onClose: () => void; children: ReactNode }) {
  return (
    <div className="fixed inset-0 z-40 grid place-items-center bg-ink/50 p-4" role="presentation" onClick={onClose}>
      <div
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className="max-h-[90dvh] w-full max-w-lg overflow-y-auto rounded-card bg-surface p-5"
        onClick={(event) => event.stopPropagation()}
      >
        <div className="mb-3 flex items-start justify-between gap-3">
          <h2 className="font-display text-3xl">{title}</h2>
          <button className="btn btn-line" type="button" onClick={onClose}>ปิด</button>
        </div>
        {children}
      </div>
    </div>
  );
}

function GroupList({ groups }: { groups: Group[] }) {
  if (!groups.length) return <p>ยังไม่มีกลุ่ม</p>;
  return (
    <ul className="grid gap-2">
      {groups.map((group) => (
        <li key={group.id} className="flex items-center gap-3 rounded-2xl border border-line px-3 py-3">
          <span className="size-4 rounded-full" style={{ background: group.color }} />
          <strong className="flex-1">{group.name}</strong>
          <span>{group.score} คะแนน</span>
        </li>
      ))}
    </ul>
  );
}

function Board({ groups }: { groups: Group[] }) {
  const rows = ranked(groups);
  if (!rows.length) return <p>ยังไม่มีคะแนน</p>;
  return (
    <ol>
      {rows.map((group) => (
        <li key={group.id} className="flex items-center gap-3 border-b border-line py-3">
          <span className="w-8 font-display text-2xl">{group.rank}</span>
          <span className="flex-1">{group.name}</span>
          <span className="font-semibold">{group.score}</span>
        </li>
      ))}
    </ol>
  );
}

function IconButton({ label, onClick, children }: { label: string; onClick: () => void; children: ReactNode }) {
  return (
    <button className="btn btn-line px-3" type="button" aria-label={label} onClick={onClick}>
      {children}
    </button>
  );
}

function move<T>(list: T[], index: number, dir: -1 | 1, commit: (next: T[]) => void) {
  const next = [...list];
  const target = index + dir;
  if (target < 0 || target >= next.length) return;
  [next[index], next[target]] = [next[target], next[index]];
  commit(next);
}

function bump(id: string, amount: number, groups: Group[], commit: (groups: Group[]) => void) {
  commit(
    groups.map((group) =>
      group.id === id ? { ...group, score: Math.max(0, group.score + amount) } : group,
    ),
  );
}
