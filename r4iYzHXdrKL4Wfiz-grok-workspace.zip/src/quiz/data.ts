export type Question = {
  id: string;
  answer: string;
  alt: string;
  image: string;
};

export type Group = {
  id: string;
  name: string;
  color: string;
  score: number;
};

export type Settings = {
  gameTitle: string;
  timer: number;
  pointsPerQ: number;
  randomize: boolean;
  sound: boolean;
  pin: string;
};

export type Award = {
  groupId: string;
  points: number;
};

export type Round = {
  order: string[];
  index: number;
  awards: Record<string, Award>;
  revealed: boolean;
  timeLeft: number;
  running: boolean;
  active: boolean;
};

export type AppData = {
  questions: Question[];
  groups: Group[];
  settings: Settings;
};

export const STORAGE_KEY = "fpc.v1";
export const TEACHER_KEY = "fpc-teacher";
export const DEFAULT_PIN = "123456789147";

export const SWATCHES = ["#c23b22", "#1d6a8a", "#246348", "#a97820", "#6b3a5d", "#3d342c"];

export const defaultSettings: Settings = {
  gameTitle: "Food Picture Quiz",
  timer: 30,
  pointsPerQ: 10,
  randomize: true,
  sound: true,
  pin: DEFAULT_PIN,
};

export const defaultQuestions: Question[] = [
  { id: "q-tom-yum", answer: "ต้มยำกุ้ง", alt: "Tom Yum Kung, ต้มยำ", image: "/food/tom-yum.jpg" },
  { id: "q-som-tum", answer: "ส้มตำ", alt: "Som Tum, ส้มตำไทย", image: "/food/som-tum.jpg" },
  { id: "q-pad-thai", answer: "ผัดไทย", alt: "Pad Thai", image: "/food/pad-thai.jpg" },
  { id: "q-khao-man", answer: "ข้าวมันไก่", alt: "Hainanese chicken rice", image: "/food/khao-man-gai.jpg" },
  { id: "q-green", answer: "แกงเขียวหวาน", alt: "Green Curry", image: "/food/green-curry.jpg" },
  { id: "q-mango", answer: "ข้าวเหนียวมะม่วง", alt: "Mango sticky rice", image: "/food/mango-sticky.jpg" },
  { id: "q-pizza", answer: "พิซซ่า", alt: "Pizza", image: "/food/pizza.jpg" },
  { id: "q-burger", answer: "แฮมเบอร์เกอร์", alt: "Hamburger, Burger", image: "/food/burger.jpg" },
  { id: "q-sushi", answer: "ซูชิ", alt: "Sushi", image: "/food/sushi.jpg" },
  { id: "q-ramen", answer: "ราเมง", alt: "Ramen", image: "/food/ramen.jpg" },
  { id: "q-steak", answer: "สเต็ก", alt: "Steak", image: "/food/steak.jpg" },
  { id: "q-spaghetti", answer: "สปาเก็ตตี้", alt: "Spaghetti, พาสต้า", image: "/food/spaghetti.jpg" },
  { id: "q-hotdog", answer: "ฮอทดอก", alt: "Hot Dog", image: "/food/hotdog.jpg" },
  { id: "q-icecream", answer: "ไอศกรีม", alt: "Ice Cream", image: "/food/icecream.jpg" },
  { id: "q-pancake", answer: "แพนเค้ก", alt: "Pancake", image: "/food/pancake.jpg" },
  { id: "q-donut", answer: "โดนัท", alt: "Donut, Doughnut", image: "/food/donut.jpg" },
  { id: "q-salad", answer: "สลัด", alt: "Salad", image: "/food/salad.jpg" },
  { id: "q-chicken", answer: "ไก่ทอด", alt: "Fried Chicken", image: "/food/chicken.jpg" },
  { id: "q-omelette", answer: "ไข่เจียว", alt: "Omelette, ออมเล็ต", image: "/food/omelette.jpg" },
  { id: "q-shabu", answer: "ชาบู", alt: "Shabu, Hot Pot", image: "/food/shabu.jpg" },
];

export const defaultGroups: Group[] = [
  { id: "g1", name: "กลุ่มมังกรทอง", color: "#c23b22", score: 0 },
  { id: "g2", name: "กลุ่มเสือดาว", color: "#1d6a8a", score: 0 },
  { id: "g3", name: "กลุ่มอินทรีฟ้า", color: "#246348", score: 0 },
  { id: "g4", name: "กลุ่มฉลามบก", color: "#a97820", score: 0 },
];

export function freshData(): AppData {
  return {
    questions: defaultQuestions.map((q) => ({ ...q })),
    groups: defaultGroups.map((g) => ({ ...g })),
    settings: { ...defaultSettings },
  };
}

export function uid(prefix: string) {
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
}

export function shuffle<T>(list: T[]): T[] {
  const next = [...list];
  for (let i = next.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [next[i], next[j]] = [next[j], next[i]];
  }
  return next;
}

export function inkOn(hex: string) {
  const h = hex.replace("#", "");
  if (!/^[0-9a-fA-F]{6}$/.test(h)) return "#fffdf8";
  const r = Number.parseInt(h.slice(0, 2), 16);
  const g = Number.parseInt(h.slice(2, 4), 16);
  const b = Number.parseInt(h.slice(4, 6), 16);
  const y = (r * 299 + g * 587 + b * 114) / 1000;
  return y > 168 ? "#241c16" : "#fffdf8";
}

export function isSafeImage(src: string) {
  if (src.startsWith("data:image/")) return src.length < 2_400_000;
  if (src.startsWith("/") && !src.startsWith("//")) return true;
  try {
    const url = new URL(src);
    return url.protocol === "http:" || url.protocol === "https:";
  } catch {
    return false;
  }
}

export function ranked(groups: Group[]) {
  const sorted = [...groups].sort(
    (a, b) => b.score - a.score || a.name.localeCompare(b.name, "th"),
  );
  let rank = 0;
  let prev = Number.POSITIVE_INFINITY;
  return sorted.map((group, index) => {
    if (group.score !== prev) rank = index + 1;
    prev = group.score;
    return { ...group, rank };
  });
}

function asQuestion(value: unknown, index: number): Question | null {
  if (!value || typeof value !== "object") return null;
  const row = value as Partial<Question>;
  if (typeof row.answer !== "string" || !row.answer.trim()) return null;
  if (typeof row.image !== "string" || !isSafeImage(row.image)) return null;
  return {
    id: typeof row.id === "string" && row.id ? row.id : `q${index + 1}`,
    answer: row.answer.trim(),
    alt: typeof row.alt === "string" ? row.alt.trim() : "",
    image: row.image,
  };
}

function asGroup(value: unknown, index: number): Group | null {
  if (!value || typeof value !== "object") return null;
  const row = value as Partial<Group>;
  if (typeof row.name !== "string" || !row.name.trim()) return null;
  const color = typeof row.color === "string" && /^#[0-9a-fA-F]{6}$/.test(row.color)
    ? row.color
    : SWATCHES[index % SWATCHES.length];
  const score = Number(row.score);
  return {
    id: typeof row.id === "string" && row.id ? row.id : `g${index + 1}`,
    name: row.name.trim(),
    color,
    score: Number.isFinite(score) ? Math.max(0, Math.round(score)) : 0,
  };
}

function asSettings(value: unknown): Settings {
  const row = (value && typeof value === "object" ? value : {}) as Partial<Settings>;
  const timer = Number(row.timer);
  const points = Number(row.pointsPerQ);
  return {
    gameTitle: typeof row.gameTitle === "string" && row.gameTitle.trim()
      ? row.gameTitle.trim().slice(0, 60)
      : defaultSettings.gameTitle,
    timer: Number.isFinite(timer) ? Math.min(3600, Math.max(5, Math.round(timer))) : defaultSettings.timer,
    pointsPerQ: Number.isFinite(points) ? Math.min(100000, Math.max(0, Math.round(points))) : defaultSettings.pointsPerQ,
    randomize: row.randomize !== false,
    sound: row.sound !== false,
    pin: typeof row.pin === "string" && row.pin.length >= 4 ? row.pin : DEFAULT_PIN,
  };
}

function asRound(value: unknown, questions: Question[]): Round | null {
  if (!value || typeof value !== "object") return null;
  const row = value as Partial<Round>;
  if (!Array.isArray(row.order)) return null;
  const known = new Set(questions.map((q) => q.id));
  const order = row.order.filter((id): id is string => typeof id === "string" && known.has(id));
  if (!order.length) return null;
  const awards: Record<string, Award> = {};
  if (row.awards && typeof row.awards === "object") {
    for (const [id, award] of Object.entries(row.awards)) {
      if (!known.has(id) || !award || typeof award !== "object") continue;
      const groupId = (award as Award).groupId;
      const points = Number((award as Award).points);
      if (typeof groupId === "string" && Number.isFinite(points)) {
        awards[id] = { groupId, points: Math.max(0, points) };
      }
    }
  }
  const index = Number(row.index);
  return {
    order,
    index: Number.isFinite(index) ? Math.min(order.length, Math.max(0, Math.round(index))) : 0,
    awards,
    revealed: Boolean(row.revealed),
    timeLeft: Number.isFinite(Number(row.timeLeft)) ? Math.max(0, Number(row.timeLeft)) : defaultSettings.timer,
    running: false,
    active: Boolean(row.active) && (Number.isFinite(index) ? index < order.length : true),
  };
}

export type Saved = { data: AppData; round: Round | null };

export function load(): Saved {
  const blank = { data: freshData(), round: null };
  if (typeof window === "undefined") return blank;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return blank;
    const parsed = JSON.parse(raw) as { data?: unknown; round?: unknown };
    const bag = (parsed.data && typeof parsed.data === "object" ? parsed.data : parsed) as {
      questions?: unknown;
      groups?: unknown;
      settings?: unknown;
    };
    const questions = Array.isArray(bag.questions)
      ? bag.questions.map(asQuestion).filter((q): q is Question => Boolean(q))
      : [];
    const groups = Array.isArray(bag.groups)
      ? bag.groups.map(asGroup).filter((g): g is Group => Boolean(g))
      : [];
    if (!questions.length) return blank;
    const data: AppData = {
      questions,
      groups,
      settings: asSettings(bag.settings),
    };
    return { data, round: asRound(parsed.round, questions) };
  } catch {
    return blank;
  }
}

export function save(saved: Saved) {
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(saved));
    return true;
  } catch {
    return false;
  }
}

export function importPayload(raw: unknown): AppData | null {
  if (!raw || typeof raw !== "object") return null;
  const bag = ("data" in raw && (raw as { data?: unknown }).data && typeof (raw as { data?: unknown }).data === "object"
    ? (raw as { data: { questions?: unknown; groups?: unknown; settings?: unknown } }).data
    : raw) as { questions?: unknown; groups?: unknown; settings?: unknown };
  if (!Array.isArray(bag.questions) || !Array.isArray(bag.groups)) return null;
  const questions = bag.questions.map(asQuestion).filter((q): q is Question => Boolean(q));
  const groups = bag.groups.map(asGroup).filter((g): g is Group => Boolean(g));
  if (!questions.length) return null;
  return { questions, groups, settings: asSettings(bag.settings) };
}

export function compressImage(file: File) {
  return new Promise<string>((resolve, reject) => {
    if (!file.type.startsWith("image/")) {
      reject(new Error("กรุณาเลือกไฟล์รูปภาพ"));
      return;
    }
    if (file.size > 12 * 1024 * 1024) {
      reject(new Error("รูปภาพใหญ่เกิน 12 MB"));
      return;
    }
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("อ่านไฟล์ไม่ได้"));
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const max = 1280;
        const scale = Math.min(1, max / Math.max(img.width, img.height));
        const canvas = document.createElement("canvas");
        canvas.width = Math.max(1, Math.round(img.width * scale));
        canvas.height = Math.max(1, Math.round(img.height * scale));
        const ctx = canvas.getContext("2d");
        if (!ctx) {
          reject(new Error("เตรียมรูปไม่สำเร็จ"));
          return;
        }
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL("image/jpeg", 0.82));
      };
      img.onerror = () => reject(new Error("เปิดรูปนี้ไม่ได้"));
      img.src = String(reader.result);
    };
    reader.readAsDataURL(file);
  });
}
