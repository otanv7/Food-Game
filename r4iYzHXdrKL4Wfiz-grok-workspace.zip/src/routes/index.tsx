import { createFileRoute } from "@tanstack/react-router";
import { QuizApp } from "@/quiz/QuizApp";

export const Route = createFileRoute("/")({
  component: QuizApp,
});
