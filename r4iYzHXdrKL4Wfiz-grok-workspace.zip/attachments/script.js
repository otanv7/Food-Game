// ข้อมูลเริ่มต้น 20 ข้อที่ผูกภาพและชื่อตรงกันอย่างแม่นยำ
const defaultQuestions = [
    { answer: "ต้มยำกุ้ง", alt: "Tom Yum Kung, ต้มยำ", image: "https://images.unsplash.com/photo-1548943487-a2e4e43b4853?w=600" },
    { answer: "ส้มตำ", alt: "Som Tum, papaya salad", image: "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=600" },
    { answer: "ผัดไทย", alt: "Pad Thai, ผัดไทยกุ้งสด", image: "https://images.unsplash.com/photo-1559847844-5315695dadae?w=600" },
    { answer: "ข้าวมันไก่", alt: "Hainanese chicken rice", image: "https://images.unsplash.com/photo-1626803775151-61d756612f97?w=600" },
    { answer: "แกงเขียวหวาน", alt: "Green Curry", image: "https://images.unsplash.com/photo-1455619452474-d2be8b1e70cd?w=600" },
    { answer: "ข้าวเหนียวมะม่วง", alt: "Mango sticky rice", image: "https://images.unsplash.com/photo-1590080875515-8a3a8dc5735e?w=600" },
    { answer: "พิซซ่า", alt: "Pizza", image: "https://images.unsplash.com/photo-1513104890138-7c749659a591?w=600" },
    { answer: "แฮมเบอร์เกอร์", alt: "Hamburger, Burger", image: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=600" },
    { answer: "ซูชิ", alt: "Sushi", image: "https://images.unsplash.com/photo-1579871494447-9811cf80d66c?w=600" },
    { answer: "ราเมง", alt: "Ramen", image: "https://images.unsplash.com/photo-1569718212165-3a8278d5f624?w=600" },
    { answer: "สเต็ก", alt: "Steak", image: "https://images.unsplash.com/photo-1600891964599-f61ba0e24092?w=600" },
    { answer: "สปาเก็ตตี", alt: "Spaghetti, พาสต้า", image: "https://images.unsplash.com/photo-1621996346565-e3d5d6283286?w=600" },
    { answer: "ฮอทดอก", alt: "Hot Dog", image: "https://images.unsplash.com/photo-1619740455993-9e612b1af08a?w=600" },
    { answer: "ไอศกรีม", alt: "Ice Cream", image: "https://images.unsplash.com/photo-1497215728101-856f4ea42174?w=600" },
    { answer: "แพนเค้ก", alt: "Pancake", image: "https://images.unsplash.com/photo-1567620905732-2d1ec7ab7445?w=600" },
    { answer: "โดนัท", alt: "Donut, Doughnut", image: "https://images.unsplash.com/photo-1551024709-8f23befc6f87?w=600" },
    { answer: "สลัด", alt: "Salad", image: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=600" },
    { answer: "ไก่ทอด", alt: "Fried Chicken", image: "https://images.unsplash.com/photo-1626645738196-c2a7c87a8f58?w=600" },
    { answer: "ไข่เจียว", alt: "Omelette, ไข่เจียว", image: "https://images.unsplash.com/photo-1565299585323-38d6b0865b47?w=600" },
    { answer: "ชาบู", alt: "Shabu, Hot Pot", image: "https://images.unsplash.com/photo-1540420773420-3366772f4999?w=600" }
];

const defaultGroups = [
    { name: "กลุ่มที่ 1 มังกรทอง", color: "#e74c3c", score: 0 },
    { name: "กลุ่มที่ 2 เสือดาว", color: "#3498db", score: 0 },
    { name: "กลุ่มที่ 3 อินทรีฟ้า", color: "#2ecc71", score: 0 },
    { name: "กลุ่มที่ 4 ฉลามบก", color: "#f39c12", score: 0 }
];

let appData = {
    questions: JSON.parse(localStorage.getItem('fpc_questions')) || defaultQuestions,
    groups: JSON.parse(localStorage.getItem('fpc_groups')) || defaultGroups,
    settings: JSON.parse(localStorage.getItem('fpc_settings')) || {
        gameTitle: "Food Picture Quiz",
        timer: 30,
        pointsPerQ: 10,
        randomize: true,
        sound: true
    }
};

let currentQuestionIndex = 0;
let questionOrder = [];
let timerInterval = null;
let timeLeft = 30;
let currentAnsweringGroupIndex = null;

function saveData() {
    localStorage.setItem('fpc_questions', JSON.stringify(appData.questions));
    localStorage.setItem('fpc_groups', JSON.stringify(appData.groups));
    localStorage.setItem('fpc_settings', JSON.stringify(appData.settings));
}

// ระบบเสียง Web Audio API
const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
function playSound(type) {
    if (!appData.settings.sound) return;
    if (audioCtx.state === 'suspended') audioCtx.resume();
    
    let osc = audioCtx.createOscillator();
    let gain = audioCtx.createGain();
    osc.connect(gain);
    gain.connect(audioCtx.destination);
    
    let now = audioCtx.currentTime;
    if (type === 'start') {
        osc.frequency.setValueAtTime(440, now);
        osc.frequency.exponentialRampToValueAtTime(880, now + 0.3);
        gain.gain.setValueAtTime(0.2, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.3);
        osc.start(now);
        osc.stop(now + 0.3);
    } else if (type === 'correct') {
        osc.frequency.setValueAtTime(523.25, now);
        osc.frequency.setValueAtTime(659.25, now + 0.1);
        osc.frequency.setValueAtTime(783.99, now + 0.2);
        gain.gain.setValueAtTime(0.2, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.4);
        osc.start(now);
        osc.stop(now + 0.4);
    } else if (type === 'timeout') {
        osc.frequency.setValueAtTime(300, now);
        osc.frequency.setValueAtTime(100, now + 0.4);
        gain.gain.setValueAtTime(0.3, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.5);
        osc.start(now);
        osc.stop(now + 0.5);
    }
}

function showScreen(screenId) {
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    document.getElementById(screenId).classList.add('active');
    closeModals();
}

function backToHome() {
    stopTimer();
    showScreen('home-screen');
}

function closeModals() {
    document.querySelectorAll('.modal').forEach(m => m.style.display = 'none');
}

function openAdminLogin() {
    document.getElementById('admin-login-modal').style.display = 'flex';
}

function verifyAdmin() {
    const pass = document.getElementById('admin-pass').value;
    if (pass === "123456789147") {
        document.getElementById('admin-pass').value = '';
        showScreen('admin-screen');
        loadAdminData();
    } else {
        alert("รหัสผ่านไม่ถูกต้อง!");
    }
}

function adminLogout() {
    backToHome();
}

function startGame() {
    playSound('start');
    currentQuestionIndex = 0;
    
    // สร้างลำดับคำถาม ป้องกัน Index เพี้ยน
    questionOrder = [...Array(appData.questions.length).keys()];
    if (appData.settings.randomize) {
        questionOrder.sort(() => Math.random() - 0.5);
    }

    document.getElementById('game-title-display').innerText = appData.settings.gameTitle;
    showScreen('game-screen');
    loadQuestion();
}

function loadQuestion() {
    stopTimer();
    if (currentQuestionIndex >= questionOrder.length) {
        endGame();
        return;
    }

    // ดึงค่าตาม index ที่ถูกต้องและสอดคล้องกันเสมอ
    const qIndex = questionOrder[currentQuestionIndex];
    const q = appData.questions[qIndex];

    document.getElementById('question-counter').innerText = `ข้อ ${currentQuestionIndex + 1}/${questionOrder.length}`;
    document.getElementById('question-image').src = q.image;
    document.getElementById('correct-answer-text').innerText = `เฉลย: ${q.answer} (${q.alt || '-'})`;
    document.getElementById('answer-overlay').style.display = 'none';
    document.getElementById('current-answering-group').innerText = 'ยังไม่ได้เลือกกลุ่ม';
    currentAnsweringGroupIndex = null;

    updateMiniScoreboard();

    timeLeft = parseInt(appData.settings.timer);
    document.getElementById('timer-display').innerText = timeLeft;
    timerInterval = setInterval(() => {
        timeLeft--;
        document.getElementById('timer-display').innerText = timeLeft;
        if (timeLeft <= 0) {
            stopTimer();
            playSound('timeout');
        }
    }, 1000);
}

function stopTimer() {
    if (timerInterval) clearInterval(timerInterval);
}

function toggleAnswer() {
    const overlay = document.getElementById('answer-overlay');
    if (overlay.style.display === 'none') {
        overlay.style.display = 'block';
        openGroupSelectModal();
    } else {
        overlay.style.display = 'none';
    }
}

function openGroupSelectModal() {
    const container = document.getElementById('group-select-buttons');
    container.innerHTML = '';
    appData.groups.forEach((g, idx) => {
        const btn = document.createElement('button');
        btn.className = 'btn';
        btn.style.backgroundColor = g.color;
        btn.innerHTML = `<i class="fa-solid fa-user-check"></i> ${g.name} (+${appData.settings.pointsPerQ})`;
        btn.onclick = () => awardPoints(idx);
        container.appendChild(btn);
    });
    document.getElementById('select-group-modal').style.display = 'flex';
}

function awardPoints(groupIndex) {
    appData.groups[groupIndex].score += parseInt(appData.settings.pointsPerQ);
    currentAnsweringGroupIndex = groupIndex;
    document.getElementById('current-answering-group').innerText = appData.groups[groupIndex].name;
    document.getElementById('current-answering-group').style.color = appData.groups[groupIndex].color;
    playSound('correct');
    saveData();
    closeModals();
    updateMiniScoreboard();
}

function nextQuestion() {
    currentQuestionIndex++;
    loadQuestion();
}

function prevQuestion() {
    if (currentQuestionIndex > 0) {
        currentQuestionIndex--;
        loadQuestion();
    }
}

function updateMiniScoreboard() {
    const board = document.getElementById('mini-scoreboard');
    board.innerHTML = '';
    appData.groups.forEach(g => {
        const card = document.createElement('div');
        card.className = 'mini-score-card';
        card.style.borderLeftColor = g.color;
        card.innerHTML = `<span><strong>${g.name}</strong></span>: <span>${g.score}</span>`;
        board.appendChild(card);
    });
}

function endGame() {
    showScreen('result-screen');
    let sortedGroups = [...appData.groups].sort((a, b) => b.score - a.score);
    const podium = document.getElementById('podium-display');
    podium.innerHTML = '';
    
    if (sortedGroups.length >= 2) {
        podium.innerHTML += `<div class="podium-item podium-2"><i class="fa-solid fa-medal"></i><br><strong>${sortedGroups[1].name}</strong><br>${sortedGroups[1].score} คะแนน</div>`;
    }
    if (sortedGroups.length >= 1) {
        podium.innerHTML += `<div class="podium-item podium-1"><i class="fa-solid fa-trophy fa-2x"></i><br><strong>${sortedGroups[0].name}</strong><br>${sortedGroups[0].score} คะแนน</div>`;
    }
    if (sortedGroups.length >= 3) {
        podium.innerHTML += `<div class="podium-item podium-3"><i class="fa-solid fa-award"></i><br><strong>${sortedGroups[2].name}</strong><br>${sortedGroups[2].score} คะแนน</div>`;
    }

    const list = document.getElementById('full-ranking-list');
    list.innerHTML = '<h3>ตารางอันดับทั้งหมด</h3>';
    sortedGroups.forEach((g, idx) => {
        list.innerHTML += `<p>อันดับ ${idx + 1}: ${g.name} - ${g.score} คะแนน</p>`;
    });
}

function toggleFullscreen() {
    if (!document.fullscreenElement) {
        document.documentElement.requestFullscreen();
    } else {
        if (document.exitFullscreen) document.exitFullscreen();
    }
}

function switchAdminTab(tabName) {
    document.querySelectorAll('.admin-tab-content').forEach(c => c.classList.remove('active'));
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.getElementById(`tab-${tabName}`).classList.add('active');
    event.currentTarget.classList.add('active');
    loadAdminData();
}

function loadAdminData() {
    const qTbody = document.querySelector('#questions-table tbody');
    qTbody.innerHTML = '';
    appData.questions.forEach((q, idx) => {
        qTbody.innerHTML += `
            <tr>
                <td>${idx + 1}</td>
                <td><img src="${q.image}" width="50" height="40" style="object-fit:cover; border-radius:4px;" onerror="this.src='https://via.placeholder.com/50'"></td>
                <td>${q.answer}</td>
                <td>${q.alt || '-'}</td>
                <td>
                    <button class="btn btn-warning" onclick="editQuestion(${idx})" style="padding:5px 10px; font-size:0.9rem;"><i class="fa-solid fa-pen"></i></button>
                    <button class="btn btn-danger" onclick="deleteQuestion(${idx})" style="padding:5px 10px; font-size:0.9rem;"><i class="fa-solid fa-trash"></i></button>
                </td>
            </tr>
        `;
    });

    const gTbody = document.querySelector('#groups-table tbody');
    gTbody.innerHTML = '';
    appData.groups.forEach((g, idx) => {
        gTbody.innerHTML += `
            <tr>
                <td><div style="width:25px; height:25px; background:${g.color}; border-radius:50%;"></div></td>
                <td>${g.name}</td>
                <td>${g.score}</td>
                <td>
                    <button class="btn btn-warning" onclick="editGroup(${idx})" style="padding:5px 10px; font-size:0.9rem;"><i class="fa-solid fa-pen"></i></button>
                    <button class="btn btn-danger" onclick="deleteGroup(${idx})" style="padding:5px 10px; font-size:0.9rem;"><i class="fa-solid fa-trash"></i></button>
                </td>
            </tr>
        `;
    });

    const sTbody = document.querySelector('#scores-manage-table tbody');
    sTbody.innerHTML = '';
    appData.groups.forEach((g, idx) => {
        sTbody.innerHTML += `
            <tr>
                <td><strong>${g.name}</strong></td>
                <td>${g.score}</td>
                <td>
                    <button class="btn btn-success" onclick="adjustScore(${idx}, 10)">+10</button>
                    <button class="btn btn-danger" onclick="adjustScore(${idx}, -10)">-10</button>
                </td>
            </tr>
        `;
    });

    document.getElementById('setting-game-title').value = appData.settings.gameTitle;
    document.getElementById('setting-timer').value = appData.settings.timer;
    document.getElementById('setting-points-per-q').value = appData.settings.pointsPerQ;
    document.getElementById('setting-randomize').checked = appData.settings.randomize;
    document.getElementById('setting-sound').checked = appData.settings.sound;
}

function openAddQuestionModal() {
    document.getElementById('q-modal-title').innerText = "เพิ่มคำถามใหม่";
    document.getElementById('edit-q-index').value = "-1";
    document.getElementById('q-answer').value = "";
    document.getElementById('q-alt-answers').value = "";
    document.getElementById('q-image-url').value = "";
    document.getElementById('q-file-input').value = "";
    document.getElementById('q-img-preview').style.display = 'none';
    document.getElementById('question-modal').style.display = 'flex';
}

function editQuestion(idx) {
    const q = appData.questions[idx];
    document.getElementById('q-modal-title').innerText = "แก้ไขคำถาม";
    document.getElementById('edit-q-index').value = idx;
    document.getElementById('q-answer').value = q.answer;
    document.getElementById('q-alt-answers').value = q.alt;
    document.getElementById('q-image-url').value = q.image;
    
    const preview = document.getElementById('q-img-preview');
    preview.src = q.image;
    preview.style.display = 'block';
    
    document.getElementById('question-modal').style.display = 'flex';
}

function previewImage(event) {
    const file = event.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            const preview = document.getElementById('q-img-preview');
            preview.src = e.target.result;
            preview.style.display = 'block';
            document.getElementById('q-image-url').value = e.target.result;
        }
        reader.readAsDataURL(file);
    }
}

function saveQuestionData() {
    const idx = parseInt(document.getElementById('edit-q-index').value);
    const answer = document.getElementById('q-answer').value;
    const alt = document.getElementById('q-alt-answers').value;
    const image = document.getElementById('q-image-url').value;

    if (!answer || !image) {
        alert("กรุณากรอกชื่ออาหารและรูปภาพให้ครบถ้วน");
        return;
    }

    const newQ = { answer, alt, image };
    if (idx === -1) {
        appData.questions.push(newQ);
    } else {
        appData.questions[idx] = newQ;
    }

    saveData();
    closeModals();
    loadAdminData();
}

function deleteQuestion(idx) {
    if (confirm("คุณต้องการลบคำถามนี้ใช่หรือไม่?")) {
        appData.questions.splice(idx, 1);
        saveData();
        loadAdminData();
    }
}

function openAddGroupModal() {
    document.getElementById('g-modal-title').innerText = "เพิ่มกลุ่มใหม่";
    document.getElementById('edit-g-index').value = "-1";
    document.getElementById('group-name-input').value = "";
    document.getElementById('group-color-input').value = "#3498db";
    document.getElementById('group-modal').style.display = 'flex';
}

function editGroup(idx) {
    const g = appData.groups[idx];
    document.getElementById('g-modal-title').innerText = "แก้ไขกลุ่ม";
    document.getElementById('edit-g-index').value = idx;
    document.getElementById('group-name-input').value = g.name;
    document.getElementById('group-color-input').value = g.color;
    document.getElementById('group-modal').style.display = 'flex';
}

function saveGroupData() {
    const idx = parseInt(document.getElementById('edit-g-index').value);
    const name = document.getElementById('group-name-input').value;
    const color = document.getElementById('group-color-input').value;

    if (!name) {
        alert("กรุณากรอกชื่อกลุ่ม");
        return;
    }

    if (idx === -1) {
        appData.groups.push({ name, color, score: 0 });
    } else {
        appData.groups[idx].name = name;
        appData.groups[idx].color = color;
    }

    saveData();
    closeModals();
    loadAdminData();
}

function deleteGroup(idx) {
    if (confirm("คุณต้องการลบกลุ่มนี้ใช่หรือไม่?")) {
        appData.groups.splice(idx, 1);
        saveData();
        loadAdminData();
    }
}

function adjustScore(idx, amount) {
    appData.groups[idx].score += amount;
    saveData();
    loadAdminData();
}

function resetScores() {
    if (confirm("คุณต้องการรีเซ็ตคะแนนทุกกลุ่มเป็น 0 ใช่หรือไม่?")) {
        appData.groups.forEach(g => g.score = 0);
        saveData();
        loadAdminData();
    }
}

function saveSettings() {
    appData.settings.gameTitle = document.getElementById('setting-game-title').value;
    appData.settings.timer = parseInt(document.getElementById('setting-timer').value);
    appData.settings.pointsPerQ = parseInt(document.getElementById('setting-points-per-q').value);
    appData.settings.randomize = document.getElementById('setting-randomize').checked;
    appData.settings.sound = document.getElementById('setting-sound').checked;
    
    saveData();
    alert("บันทึกการตั้งค่าเรียบร้อยแล้ว!");
}

function exportData() {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(appData, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", "food_picture_quiz_backup.json");
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
}

function importData(event) {
    const file = event.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            try {
                appData = JSON.parse(e.target.result);
                saveData();
                loadAdminData();
                alert("นำเข้าข้อมูลสำเร็จ!");
            } catch (err) {
                alert("ไฟล์ JSON ไม่ถูกต้อง!");
            }
        };
        reader.readAsText(file);
    }
}

function factoryReset() {
    if (confirm("คำเตือน: ข้อมูลทั้งหมดจะถูกลบและกลับเป็นค่าเริ่มต้น คุณแน่ใจหรือไม่?")) {
        localStorage.clear();
        location.reload();
    }
}

function openLeaderboardModal() {
    const content = document.getElementById('leaderboard-content');
    content.innerHTML = '';
    let sorted = [...appData.groups].sort((a, b) => b.score - a.score);
    sorted.forEach((g, idx) => {
        content.innerHTML += `<p style="padding:8px; border-bottom:1px solid #eee;"><strong>อันดับ ${idx + 1}:</strong> ${g.name} - ${g.score} คะแนน</p>`;
    });
    document.getElementById('leaderboard-modal').style.display = 'flex';
}

function openGroupsModal() {
    openLeaderboardModal();
}
function loadQuestion() {
  stopTimer();

  if (currentQuestionIndex >= questionOrder.length) {
    endGame();
    return;
  }

  const q = currentQuestion();

  if (!q) {
    alert("ไม่พบคำถามนี้ อาจมีการแก้ไขรายการระหว่างเล่น");
    backToHome();
    return;
  }

  const image = document.getElementById("question-image");

  image.onerror = () => {
    image.src = foodIllustration("🍽️","#eeeeee");
    image.alt = "ไม่สามารถโหลดภาพได้";
  };

  image.src = q.image || foodIllustration("🍽️");
  image.alt = "ภาพประกอบคำถามอาหาร";

  document.getElementById("question-counter").textContent =
    `ข้อ ${currentQuestionIndex+1}/${questionOrder.length}`;

  document.getElementById("correct-answer-text").textContent =
    `เฉลย: ${q.answer}`;

  document.getElementById("answer-overlay").style.display = "none";

  const groupLabel = document.getElementById("current-answering-group");

  groupLabel.textContent = awardedQuestionIds.has(q.id)
    ? (findGroupName(currentAnsweringGroupId) || "ให้คะแนนข้อนี้แล้ว")
    : "ยังไม่ได้เลือกกลุ่ม";

  groupLabel.style.color = "";
  currentAnsweringGroupId = null;

  updateMiniScoreboard();
  startTimer();
}

function startTimer() {
  stopTimer();

  timeLeft = Math.max(1, Number(appData.settings.timer)||30);

  document.getElementById("timer-display").textContent = timeLeft;
  document.getElementById("timer-box").classList.remove("time-up");

  timerInterval = setInterval(()=>{
    timeLeft--;

    document.getElementById("timer-display").textContent = timeLeft;

    if (timeLeft <= 0) {
      stopTimer();
      document.getElementById("timer-box").classList.add("time-up");
      playSound("timeout");
    }
  },1000);
}

function stopTimer() {
  if (timerInterval !== null) {
    clearInterval(timerInterval);
    timerInterval = null;
  }
}

function toggleAnswer() {
  const overlay = document.getElementById("answer-overlay");
  const showing = overlay.style.display !== "none";

  if (showing) {
    overlay.style.display = "none";
    return;
  }

  stopTimer();
  overlay.style.display = "block";

  const q = currentQuestion();

  if (q && !awardedQuestionIds.has(q.id)) {
    openGroupSelectModal();
  }
}

function openGroupSelectModal() {
  const q = currentQuestion();

  if (!q || awardedQuestionIds.has(q.id)) return;

  const container = document.getElementById("group-select-buttons");
  container.replaceChildren();

  if (!appData.groups.length) {
    container.textContent = "ยังไม่มีกลุ่ม กรุณาเพิ่มกลุ่มในหน้าแอดมิน";
  }

  appData.groups.forEach(g=>{
    const btn = document.createElement("button");

    btn.className = "btn";
    btn.style.backgroundColor = g.color;
    btn.textContent =
      `${g.name} (+${Number(appData.settings.pointsPerQ)||10})`;

    btn.addEventListener("click",()=>awardPoints(g.id));

    container.appendChild(btn);
  });

  document.getElementById("select-group-modal").style.display = "flex";
}

function awardPoints(groupId) {
  const q = currentQuestion();
  const group = appData.groups.find(g=>g.id===groupId);

  if (!q || !group || awardedQuestionIds.has(q.id)) return;

  const points = Math.max(0,Number(appData.settings.pointsPerQ)||0);

  group.score += points;
  awardedQuestionIds.add(q.id);
  currentAnsweringGroupId = group.id;

  const label = document.getElementById("current-answering-group");

  label.textContent = group.name;
  label.style.color = group.color;

  playSound("correct");
  saveData();
  closeModals();
  updateMiniScoreboard();
}

function nextQuestion() {
  if (currentQuestionIndex < questionOrder.length) {
    currentQuestionIndex++;
    loadQuestion();
  }
}

function prevQuestion() {
  if (currentQuestionIndex > 0) {
    currentQuestionIndex--;
    loadQuestion();
  }
}

function updateMiniScoreboard() {
  const board = document.getElementById("mini-scoreboard");
  board.replaceChildren();

  appData.groups.forEach(g=>{
    const card = document.createElement("div");
    card.className = "mini-score-card";
    card.style.borderLeftColor = g.color;

    const name = document.createElement("strong");
    name.textContent = g.name;

    const score = document.createElement("span");
    score.textContent = `${g.score} คะแนน`;

    card.append(name,score);
    board.appendChild(card);
  });
}

function endGame() {
  stopTimer();
  showScreen("result-screen");

  const sorted = [...appData.groups].sort((a,b)=>b.score-a.score);
  const podium = document.getElementById("podium-display");

  podium.replaceChildren();

  const podiumOrder = [
    {rank:1,cls:"podium-1",icon:"🏆"},
    {rank:0,cls:"podium-2",icon:"🥈"},
    {rank:2,cls:"podium-3",icon:"🥉"}
  ];

  podiumOrder.forEach(p=>{
    if (sorted[p.rank]) {
      const g = sorted[p.rank];
      const item = document.createElement("div");

      item.className = `podium-item ${p.cls}`;
      item.textContent = `${p.icon} ${g.name} ${g.score} คะแนน`;

      podium.appendChild(item);
    }
  });

  const list = document.getElementById("full-ranking-list");
  list.replaceChildren();

  const heading = document.createElement("h3");
  heading.textContent = "ตารางอันดับทั้งหมด";

  list.appendChild(heading);

  sorted.forEach((g,i)=>{
    const p = document.createElement("p");
    p.textContent = `อันดับ ${i+1}: ${g.name} — ${g.score} คะแนน`;
    list.appendChild(p);
  });
}

function toggleFullscreen() {
  if (!document.fullscreenElement) {
    document.documentElement.requestFullscreen?.().catch(()=>{});
  } else {
    document.exitFullscreen?.();
  }
}

function switchAdminTab(tabName) {
  if (!requireAdmin()) return;

  currentAdminTab = tabName;

  document.querySelectorAll(".admin-tab-content").forEach(c=>{
    c.classList.toggle("active",c.id===`tab-${tabName}`);
  });

  document.querySelectorAll(".tab-btn").forEach(b=>{
    b.classList.toggle(
      "active",
      b.getAttribute("onclick")?.includes(`'${tabName}'`)
    );
  });

  loadAdminData();
}

function loadAdminData() {
  if (!adminAuthenticated) return;

  const qTbody = document.querySelector("#questions-table tbody");
  qTbody.replaceChildren();

  appData.questions.forEach((q,i)=>{
    const tr = document.createElement("tr");

    tr.innerHTML = `
      <td>${i+1}</td>
      <td><img class="admin-thumb" src="${q.image}" alt="ภาพข้อ ${i+1}"></td>
      <td></td>
      <td></td>
      <td></td>
    `;

    tr.children[2].textContent = q.answer;
    tr.children[3].textContent = q.alt || "-";

    tr.children[4].innerHTML = `
      <button class="btn btn-warning" onclick="editQuestion(${i})" aria-label="แก้ไข">✏️</button>
      <button class="btn btn-danger" onclick="deleteQuestion(${i})" aria-label="ลบ">🗑️</button>
    `;

    qTbody.appendChild(tr);
  });

  const gTbody = document.querySelector("#groups-table tbody");
  gTbody.replaceChildren();

  appData.groups.forEach((g,i)=>{
    const tr = document.createElement("tr");

    tr.innerHTML = `
      <td><span class="color-dot" style="background:${g.color}"></span></td>
      <td></td>
      <td>${g.score}</td>
      <td>
        <button class="btn btn-warning" onclick="editGroup(${i})">✏️</button>
        <button class="btn btn-danger" onclick="deleteGroup(${i})">🗑️</button>
      </td>
    `;

    tr.children[1].textContent = g.name;
    gTbody.appendChild(tr);
  });

  const sTbody = document.querySelector("#scores-manage-table tbody");
  sTbody.replaceChildren();

  appData.groups.forEach((g,i)=>{
    const tr = document.createElement("tr");

    tr.innerHTML = `
      <td></td>
      <td>${g.score}</td>
      <td>
        <button class="btn btn-success" onclick="adjustScore(${i},10)">+10</button>
        <button class="btn btn-danger" onclick="adjustScore(${i},-10)">-10</button>
      </td>
    `;

    tr.children[0].textContent = g.name;
    sTbody.appendChild(tr);
  });

  document.getElementById("setting-game-title").value =
    appData.settings.gameTitle;

  document.getElementById("setting-timer").value =
    appData.settings.timer;

  document.getElementById("setting-points-per-q").value =
    appData.settings.pointsPerQ;

  document.getElementById("setting-randomize").checked =
    !!appData.settings.randomize;

  document.getElementById("setting-sound").checked =
    !!appData.settings.sound;
}

function openAddQuestionModal() {
  if (!requireAdmin()) return;

  document.getElementById("q-modal-title").textContent = "เพิ่มคำถามใหม่";
  document.getElementById("edit-q-index").value = "-1";
  document.getElementById("q-answer").value = "";
  document.getElementById("q-alt-answers").value = "";
  document.getElementById("q-image-url").value = "";
  document.getElementById("q-file-input").value = "";

  const preview = document.getElementById("q-img-preview");

  preview.removeAttribute("src");
  preview.style.display = "none";

  document.getElementById("question-modal").style.display = "flex";
}

function editQuestion(idx) {
  if (!requireAdmin()) return;

  const q = appData.questions[idx];
  if (!q) return;

  document.getElementById("q-modal-title").textContent = "แก้ไขคำถาม";
  document.getElementById("edit-q-index").value = idx;
  document.getElementById("q-answer").value = q.answer;
  document.getElementById("q-alt-answers").value = q.alt;

  document.getElementById("q-image-url").value =
    q.image.startsWith("data:image/") ? "" : q.image;

  document.getElementById("q-file-input").value = "";

  const preview = document.getElementById("q-img-preview");

  preview.src = q.image;
  preview.style.display = "block";

  document.getElementById("question-modal").style.display = "flex";
}

function previewImage(event) {
  const file = event.target.files?.[0];
  if (!file) return;

  if (!file.type.startsWith("image/")) {
    alert("กรุณาเลือกไฟล์รูปภาพ");
    event.target.value = "";
    return;
  }

  if (file.size > 8*1024*1024) {
    alert("รูปภาพมีขนาดเกิน 8 MB กรุณาเลือกภาพที่เล็กลง");
    event.target.value = "";
    return;
  }

  const reader = new FileReader();

  reader.onload = e=>{
    const img = new Image();

    img.onload = ()=>{
      const max = 1200;
      const scale = Math.min(1,max/Math.max(img.width,img.height));

      const canvas = document.createElement("canvas");

      canvas.width = Math.round(img.width*scale);
      canvas.height = Math.round(img.height*scale);

      canvas.getContext("2d").drawImage(
        img,0,0,canvas.width,canvas.height
      );

      const compressed = canvas.toDataURL("image/jpeg",.82);

      document.getElementById("q-img-preview").src = compressed;
      document.getElementById("q-img-preview").style.display = "block";
      document.getElementById("q-image-url").value = compressed;
    };

    img.onerror = ()=>alert("อ่านรูปภาพนี้ไม่ได้");
    img.src = e.target.result;
  };

  reader.readAsDataURL(file);
}
function saveQuestionData() {
  if (!requireAdmin()) return;

  const idx = Number.parseInt(
    document.getElementById("edit-q-index").value,
    10
  );

  const answer = document.getElementById("q-answer").value.trim();
  const alt = document.getElementById("q-alt-answers").value.trim();
  const file = document.getElementById("q-file-input").files?.[0];

  const image =
    document.getElementById("q-image-url").value.trim() ||
    (idx >= 0 ? appData.questions[idx]?.image : "");

  if (!answer || (!image && !file)) {
    alert("กรุณากรอกชื่ออาหารและเลือกรูปภาพให้ครบ");
    return;
  }

  const commit = img => {
    const old = idx >= 0 ? appData.questions[idx] : null;

    const q = {
      id: old?.id || `q_${Date.now()}_${Math.random().toString(36).slice(2,7)}`,
      answer,
      alt,
      image: img || image
    };

    if (idx < 0) {
      appData.questions.push(q);
    } else {
      appData.questions[idx] = q;
    }

    if (saveData()) {
      closeModals();
      loadAdminData();
    }
  };

  if (file) {
    const preview = document.getElementById("q-img-preview");

    if (preview.src.startsWith("data:image/")) {
      commit(preview.src);
    } else {
      alert("กรุณารอให้ระบบเตรียมรูปภาพเสร็จก่อน");
    }
  } else {
    commit(image);
  }
}

function deleteQuestion(idx) {
  if (!requireAdmin()) return;

  if (confirm("ต้องการลบคำถามนี้ใช่หรือไม่?")) {
    appData.questions.splice(idx,1);
    saveData();
    loadAdminData();
  }
}

function openAddGroupModal() {
  if (!requireAdmin()) return;

  document.getElementById("g-modal-title").textContent = "เพิ่มกลุ่มใหม่";
  document.getElementById("edit-g-index").value = "-1";
  document.getElementById("group-name-input").value = "";
  document.getElementById("group-color-input").value = "#3498db";

  document.getElementById("group-modal").style.display = "flex";
}

function editGroup(idx) {
  if (!requireAdmin()) return;

  const g = appData.groups[idx];
  if (!g) return;

  document.getElementById("g-modal-title").textContent = "แก้ไขกลุ่ม";
  document.getElementById("edit-g-index").value = idx;
  document.getElementById("group-name-input").value = g.name;
  document.getElementById("group-color-input").value = g.color;

  document.getElementById("group-modal").style.display = "flex";
}

function saveGroupData() {
  if (!requireAdmin()) return;

  const idx = Number.parseInt(
    document.getElementById("edit-g-index").value,
    10
  );

  const name = document.getElementById("group-name-input").value.trim();
  const color = document.getElementById("group-color-input").value;

  if (!name) {
    alert("กรุณากรอกชื่อกลุ่ม");
    return;
  }

  if (idx < 0) {
    appData.groups.push({
      id: `g_${Date.now()}`,
      name,
      color,
      score: 0
    });
  } else if (appData.groups[idx]) {
    appData.groups[idx].name = name;
    appData.groups[idx].color = color;
  }

  if (saveData()) {
    closeModals();
    loadAdminData();
    updateMiniScoreboard();
  }
}

function deleteGroup(idx) {
  if (!requireAdmin()) return;

  if (confirm("ต้องการลบกลุ่มนี้ใช่หรือไม่?")) {
    appData.groups.splice(idx,1);
    saveData();
    loadAdminData();
    updateMiniScoreboard();
  }
}

function adjustScore(idx,amount) {
  if (!requireAdmin() || !appData.groups[idx]) return;

  appData.groups[idx].score = Math.max(
    0,
    appData.groups[idx].score + amount
  );

  saveData();
  loadAdminData();
  updateMiniScoreboard();
}

function resetScores() {
  if (!requireAdmin()) return;

  if (confirm("ต้องการรีเซ็ตคะแนนทุกกลุ่มเป็น 0 ใช่หรือไม่?")) {
    appData.groups.forEach(g=>g.score=0);
    awardedQuestionIds.clear();

    saveData();
    loadAdminData();
    updateMiniScoreboard();
  }
}

function saveSettings() {
  if (!requireAdmin()) return;

  const title = document.getElementById("setting-game-title").value.trim();

  const timer = Number.parseInt(
    document.getElementById("setting-timer").value,
    10
  );

  const points = Number.parseInt(
    document.getElementById("setting-points-per-q").value,
    10
  );

  if (
    !title ||
    !Number.isFinite(timer) ||
    timer < 1 ||
    timer > 3600 ||
    !Number.isFinite(points) ||
    points < 0 ||
    points > 100000
  ) {
    alert("กรุณาตรวจสอบชื่อเกม เวลา (1–3600 วินาที) และคะแนน (0–100000)");
    return;
  }

  appData.settings = {
    gameTitle: title,
    timer,
    pointsPerQ: points,
    randomize: document.getElementById("setting-randomize").checked,
    sound: document.getElementById("setting-sound").checked
  };

  saveData();

  document.getElementById("game-title-display").textContent = title;

  alert("บันทึกการตั้งค่าเรียบร้อยแล้ว");
}

function exportData() {
  if (!requireAdmin()) return;

  const blob = new Blob(
    [JSON.stringify(appData,null,2)],
    {type:"application/json"}
  );

  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");

  a.href = url;
  a.download = "food-picture-quiz-backup.json";
  a.click();

  URL.revokeObjectURL(url);
}

function importData(event) {
  if (!requireAdmin()) return;

  const file = event.target.files?.[0];
  if (!file) return;

  const reader = new FileReader();

  reader.onload = ()=>{
    try {
      const data = JSON.parse(reader.result);

      if (
        !data ||
        !Array.isArray(data.questions) ||
        !Array.isArray(data.groups) ||
        !data.settings
      ) {
        throw new Error("โครงสร้างข้อมูลไม่ครบ");
      }

      if (!data.questions.every(
        q => q &&
        typeof q.answer === "string" &&
        typeof q.image === "string"
      )) {
        throw new Error("ข้อมูลคำถามไม่ถูกต้อง");
      }

      if (!data.groups.every(
        g => g && typeof g.name === "string"
      )) {
        throw new Error("ข้อมูลกลุ่มไม่ถูกต้อง");
      }

      appData = {
        questions: data.questions.map((q,i)=>({
          id: q.id || `q${i+1}`,
          answer: q.answer,
          alt: q.alt || "",
          image: q.image
        })),

        groups: data.groups.map((g,i)=>({
          id: g.id || `g${i+1}`,
          name: g.name,
          color: g.color || "#3498db",
          score: Number(g.score) || 0
        })),

        settings: {
          ...defaultSettings,
          ...data.settings
        }
      };

      if (saveData()) {
        loadAdminData();
        alert("นำเข้าข้อมูลสำเร็จ");
      }

    } catch(err) {
      alert(`นำเข้าข้อมูลไม่สำเร็จ: ${err.message}`);
    }

    event.target.value = "";
  };

  reader.readAsText(file);
}

function factoryReset() {
  if (!requireAdmin()) return;

  if (
    confirm(
      "ข้อมูลคำถาม กลุ่ม และการตั้งค่าทั้งหมดจะกลับเป็นค่าเริ่มต้น ยืนยันหรือไม่?"
    )
  ) {
    appData = {
      questions: structuredCloneSafe(defaultQuestions),
      groups: structuredCloneSafe(defaultGroups),
      settings: {...defaultSettings}
    };

    awardedQuestionIds.clear();

    saveData();
    loadAdminData();

    alert("คืนค่าเริ่มต้นแล้ว");
  }
}

function findGroupName(id) {
  return appData.groups.find(g=>g.id===id)?.name || "";
}

function openLeaderboardModal() {
  const content = document.getElementById("leaderboard-content");
  content.replaceChildren();

  const sorted = [...appData.groups].sort(
    (a,b)=>b.score-a.score
  );

  sorted.forEach((g,i)=>{
    const p = document.createElement("p");

    p.className = "leaderboard-row";
    p.textContent =
      `อันดับ ${i+1}: ${g.name} — ${g.score} คะแนน`;

    content.appendChild(p);
  });

  document.getElementById("leaderboard-modal").style.display = "flex";
}

function openGroupsModal() {
  const content = document.getElementById("groups-list-content");
  content.replaceChildren();

  appData.groups.forEach(g=>{
    const row = document.createElement("div");
    row.className = "public-group-row";

    const dot = document.createElement("span");
    dot.className = "color-dot";
    dot.style.backgroundColor = g.color;

    const name = document.createElement("strong");
    name.textContent = g.name;

    const score = document.createElement("span");
    score.textContent = `${g.score} คะแนน`;

    row.append(dot,name,score);
    content.appendChild(row);
  });

  document.getElementById("groups-list-modal").style.display = "flex";
}

document.addEventListener("keydown",e=>{
  if (
    e.key === "Enter" &&
    document.getElementById("admin-login-modal").style.display === "flex"
  ) {
    verifyAdmin();
  }

  if (e.key === "Escape") {
    closeModals();
  }
});

document.addEventListener("DOMContentLoaded",()=>{
  document.getElementById("app-title").innerHTML =
    '<i class="fa-solid fa-utensils"></i> ' +
    (appData.settings.gameTitle || "Food Picture Quiz");

  document.getElementById("game-title-display").textContent =
    appData.settings.gameTitle;

  if (!localStorage.getItem(STORAGE_KEYS.questions)) {
    saveData();
  }
});