import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as Database, D as ChevronDown, E as ChevronLeft, S as Download, T as ChevronRight, _ as Maximize2, a as Upload, b as Eye, c as Trash2, d as RotateCcw, f as Plus, g as Medal, h as Pause, i as Users, l as Timer, m as Pencil, n as Volume2, o as Trophy, p as Play, r as UtensilsCrossed, t as VolumeX, u as SlidersHorizontal, v as Lock, w as ChevronUp, x as EyeOff, y as House } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BxM06rcU.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ctx = null;
function unlockAudio() {
	const AudioCtx = window.AudioContext || window.webkitAudioContext;
	if (!AudioCtx) return;
	if (!ctx) ctx = new AudioCtx();
	if (ctx.state === "suspended") ctx.resume();
}
function playCue(kind, enabled) {
	if (!enabled) return;
	unlockAudio();
	if (!ctx) return;
	const osc = ctx.createOscillator();
	const gain = ctx.createGain();
	osc.connect(gain);
	gain.connect(ctx.destination);
	const now = ctx.currentTime;
	gain.gain.setValueAtTime(1e-4, now);
	if (kind === "start") {
		osc.frequency.setValueAtTime(440, now);
		osc.frequency.exponentialRampToValueAtTime(880, now + .22);
		gain.gain.exponentialRampToValueAtTime(.18, now + .02);
		gain.gain.exponentialRampToValueAtTime(1e-4, now + .28);
		osc.start(now);
		osc.stop(now + .3);
	} else if (kind === "correct") {
		osc.type = "triangle";
		osc.frequency.setValueAtTime(523.25, now);
		osc.frequency.setValueAtTime(659.25, now + .09);
		osc.frequency.setValueAtTime(783.99, now + .18);
		gain.gain.exponentialRampToValueAtTime(.2, now + .02);
		gain.gain.exponentialRampToValueAtTime(1e-4, now + .38);
		osc.start(now);
		osc.stop(now + .4);
	} else {
		osc.type = "sawtooth";
		osc.frequency.setValueAtTime(280, now);
		osc.frequency.exponentialRampToValueAtTime(90, now + .35);
		gain.gain.exponentialRampToValueAtTime(.16, now + .02);
		gain.gain.exponentialRampToValueAtTime(1e-4, now + .4);
		osc.start(now);
		osc.stop(now + .42);
	}
}
var STORAGE_KEY = "fpc.v1";
var TEACHER_KEY = "fpc-teacher";
var DEFAULT_PIN = "123456789147";
var SWATCHES = [
	"#c23b22",
	"#1d6a8a",
	"#246348",
	"#a97820",
	"#6b3a5d",
	"#3d342c"
];
var defaultSettings = {
	gameTitle: "Food Picture Quiz",
	timer: 30,
	pointsPerQ: 10,
	randomize: true,
	sound: true,
	pin: DEFAULT_PIN
};
var defaultQuestions = [
	{
		id: "q-tom-yum",
		answer: "ต้มยำกุ้ง",
		alt: "Tom Yum Kung, ต้มยำ",
		image: "/food/tom-yum.jpg"
	},
	{
		id: "q-som-tum",
		answer: "ส้มตำ",
		alt: "Som Tum, ส้มตำไทย",
		image: "/food/som-tum.jpg"
	},
	{
		id: "q-pad-thai",
		answer: "ผัดไทย",
		alt: "Pad Thai",
		image: "/food/pad-thai.jpg"
	},
	{
		id: "q-khao-man",
		answer: "ข้าวมันไก่",
		alt: "Hainanese chicken rice",
		image: "/food/khao-man-gai.jpg"
	},
	{
		id: "q-green",
		answer: "แกงเขียวหวาน",
		alt: "Green Curry",
		image: "/food/green-curry.jpg"
	},
	{
		id: "q-mango",
		answer: "ข้าวเหนียวมะม่วง",
		alt: "Mango sticky rice",
		image: "/food/mango-sticky.jpg"
	},
	{
		id: "q-pizza",
		answer: "พิซซ่า",
		alt: "Pizza",
		image: "/food/pizza.jpg"
	},
	{
		id: "q-burger",
		answer: "แฮมเบอร์เกอร์",
		alt: "Hamburger, Burger",
		image: "/food/burger.jpg"
	},
	{
		id: "q-sushi",
		answer: "ซูชิ",
		alt: "Sushi",
		image: "/food/sushi.jpg"
	},
	{
		id: "q-ramen",
		answer: "ราเมง",
		alt: "Ramen",
		image: "/food/ramen.jpg"
	},
	{
		id: "q-steak",
		answer: "สเต็ก",
		alt: "Steak",
		image: "/food/steak.jpg"
	},
	{
		id: "q-spaghetti",
		answer: "สปาเก็ตตี้",
		alt: "Spaghetti, พาสต้า",
		image: "/food/spaghetti.jpg"
	},
	{
		id: "q-hotdog",
		answer: "ฮอทดอก",
		alt: "Hot Dog",
		image: "/food/hotdog.jpg"
	},
	{
		id: "q-icecream",
		answer: "ไอศกรีม",
		alt: "Ice Cream",
		image: "/food/icecream.jpg"
	},
	{
		id: "q-pancake",
		answer: "แพนเค้ก",
		alt: "Pancake",
		image: "/food/pancake.jpg"
	},
	{
		id: "q-donut",
		answer: "โดนัท",
		alt: "Donut, Doughnut",
		image: "/food/donut.jpg"
	},
	{
		id: "q-salad",
		answer: "สลัด",
		alt: "Salad",
		image: "/food/salad.jpg"
	},
	{
		id: "q-chicken",
		answer: "ไก่ทอด",
		alt: "Fried Chicken",
		image: "/food/chicken.jpg"
	},
	{
		id: "q-omelette",
		answer: "ไข่เจียว",
		alt: "Omelette, ออมเล็ต",
		image: "/food/omelette.jpg"
	},
	{
		id: "q-shabu",
		answer: "ชาบู",
		alt: "Shabu, Hot Pot",
		image: "/food/shabu.jpg"
	}
];
var defaultGroups = [
	{
		id: "g1",
		name: "กลุ่มมังกรทอง",
		color: "#c23b22",
		score: 0
	},
	{
		id: "g2",
		name: "กลุ่มเสือดาว",
		color: "#1d6a8a",
		score: 0
	},
	{
		id: "g3",
		name: "กลุ่มอินทรีฟ้า",
		color: "#246348",
		score: 0
	},
	{
		id: "g4",
		name: "กลุ่มฉลามบก",
		color: "#a97820",
		score: 0
	}
];
function freshData() {
	return {
		questions: defaultQuestions.map((q) => ({ ...q })),
		groups: defaultGroups.map((g) => ({ ...g })),
		settings: { ...defaultSettings }
	};
}
function uid(prefix) {
	return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
}
function shuffle(list) {
	const next = [...list];
	for (let i = next.length - 1; i > 0; i -= 1) {
		const j = Math.floor(Math.random() * (i + 1));
		[next[i], next[j]] = [next[j], next[i]];
	}
	return next;
}
function inkOn(hex) {
	const h = hex.replace("#", "");
	if (!/^[0-9a-fA-F]{6}$/.test(h)) return "#fffdf8";
	const r = Number.parseInt(h.slice(0, 2), 16);
	const g = Number.parseInt(h.slice(2, 4), 16);
	const b = Number.parseInt(h.slice(4, 6), 16);
	return (r * 299 + g * 587 + b * 114) / 1e3 > 168 ? "#241c16" : "#fffdf8";
}
function isSafeImage(src) {
	if (src.startsWith("data:image/")) return src.length < 24e5;
	if (src.startsWith("/") && !src.startsWith("//")) return true;
	try {
		const url = new URL(src);
		return url.protocol === "http:" || url.protocol === "https:";
	} catch {
		return false;
	}
}
function ranked(groups) {
	const sorted = [...groups].sort((a, b) => b.score - a.score || a.name.localeCompare(b.name, "th"));
	let rank = 0;
	let prev = Number.POSITIVE_INFINITY;
	return sorted.map((group, index) => {
		if (group.score !== prev) rank = index + 1;
		prev = group.score;
		return {
			...group,
			rank
		};
	});
}
function asQuestion(value, index) {
	if (!value || typeof value !== "object") return null;
	const row = value;
	if (typeof row.answer !== "string" || !row.answer.trim()) return null;
	if (typeof row.image !== "string" || !isSafeImage(row.image)) return null;
	return {
		id: typeof row.id === "string" && row.id ? row.id : `q${index + 1}`,
		answer: row.answer.trim(),
		alt: typeof row.alt === "string" ? row.alt.trim() : "",
		image: row.image
	};
}
function asGroup(value, index) {
	if (!value || typeof value !== "object") return null;
	const row = value;
	if (typeof row.name !== "string" || !row.name.trim()) return null;
	const color = typeof row.color === "string" && /^#[0-9a-fA-F]{6}$/.test(row.color) ? row.color : SWATCHES[index % SWATCHES.length];
	const score = Number(row.score);
	return {
		id: typeof row.id === "string" && row.id ? row.id : `g${index + 1}`,
		name: row.name.trim(),
		color,
		score: Number.isFinite(score) ? Math.max(0, Math.round(score)) : 0
	};
}
function asSettings(value) {
	const row = value && typeof value === "object" ? value : {};
	const timer = Number(row.timer);
	const points = Number(row.pointsPerQ);
	return {
		gameTitle: typeof row.gameTitle === "string" && row.gameTitle.trim() ? row.gameTitle.trim().slice(0, 60) : defaultSettings.gameTitle,
		timer: Number.isFinite(timer) ? Math.min(3600, Math.max(5, Math.round(timer))) : defaultSettings.timer,
		pointsPerQ: Number.isFinite(points) ? Math.min(1e5, Math.max(0, Math.round(points))) : defaultSettings.pointsPerQ,
		randomize: row.randomize !== false,
		sound: row.sound !== false,
		pin: typeof row.pin === "string" && row.pin.length >= 4 ? row.pin : DEFAULT_PIN
	};
}
function asRound(value, questions) {
	if (!value || typeof value !== "object") return null;
	const row = value;
	if (!Array.isArray(row.order)) return null;
	const known = new Set(questions.map((q) => q.id));
	const order = row.order.filter((id) => typeof id === "string" && known.has(id));
	if (!order.length) return null;
	const awards = {};
	if (row.awards && typeof row.awards === "object") for (const [id, award] of Object.entries(row.awards)) {
		if (!known.has(id) || !award || typeof award !== "object") continue;
		const groupId = award.groupId;
		const points = Number(award.points);
		if (typeof groupId === "string" && Number.isFinite(points)) awards[id] = {
			groupId,
			points: Math.max(0, points)
		};
	}
	const index = Number(row.index);
	return {
		order,
		index: Number.isFinite(index) ? Math.min(order.length, Math.max(0, Math.round(index))) : 0,
		awards,
		revealed: Boolean(row.revealed),
		timeLeft: Number.isFinite(Number(row.timeLeft)) ? Math.max(0, Number(row.timeLeft)) : defaultSettings.timer,
		running: false,
		active: Boolean(row.active) && (Number.isFinite(index) ? index < order.length : true)
	};
}
function load() {
	const blank = {
		data: freshData(),
		round: null
	};
	if (typeof window === "undefined") return blank;
	try {
		const raw = window.localStorage.getItem(STORAGE_KEY);
		if (!raw) return blank;
		const parsed = JSON.parse(raw);
		const bag = parsed.data && typeof parsed.data === "object" ? parsed.data : parsed;
		const questions = Array.isArray(bag.questions) ? bag.questions.map(asQuestion).filter((q) => Boolean(q)) : [];
		const groups = Array.isArray(bag.groups) ? bag.groups.map(asGroup).filter((g) => Boolean(g)) : [];
		if (!questions.length) return blank;
		return {
			data: {
				questions,
				groups,
				settings: asSettings(bag.settings)
			},
			round: asRound(parsed.round, questions)
		};
	} catch {
		return blank;
	}
}
function save(saved) {
	try {
		window.localStorage.setItem(STORAGE_KEY, JSON.stringify(saved));
		return true;
	} catch {
		return false;
	}
}
function importPayload(raw) {
	if (!raw || typeof raw !== "object") return null;
	const bag = "data" in raw && raw.data && typeof raw.data === "object" ? raw.data : raw;
	if (!Array.isArray(bag.questions) || !Array.isArray(bag.groups)) return null;
	const questions = bag.questions.map(asQuestion).filter((q) => Boolean(q));
	const groups = bag.groups.map(asGroup).filter((g) => Boolean(g));
	if (!questions.length) return null;
	return {
		questions,
		groups,
		settings: asSettings(bag.settings)
	};
}
function compressImage(file) {
	return new Promise((resolve, reject) => {
		if (!file.type.startsWith("image/")) {
			reject(/* @__PURE__ */ new Error("กรุณาเลือกไฟล์รูปภาพ"));
			return;
		}
		if (file.size > 12582912) {
			reject(/* @__PURE__ */ new Error("รูปภาพใหญ่เกิน 12 MB"));
			return;
		}
		const reader = new FileReader();
		reader.onerror = () => reject(/* @__PURE__ */ new Error("อ่านไฟล์ไม่ได้"));
		reader.onload = () => {
			const img = new Image();
			img.onload = () => {
				const scale = Math.min(1, 1280 / Math.max(img.width, img.height));
				const canvas = document.createElement("canvas");
				canvas.width = Math.max(1, Math.round(img.width * scale));
				canvas.height = Math.max(1, Math.round(img.height * scale));
				const ctx = canvas.getContext("2d");
				if (!ctx) {
					reject(/* @__PURE__ */ new Error("เตรียมรูปไม่สำเร็จ"));
					return;
				}
				ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
				resolve(canvas.toDataURL("image/jpeg", .82));
			};
			img.onerror = () => reject(/* @__PURE__ */ new Error("เปิดรูปนี้ไม่ได้"));
			img.src = String(reader.result);
		};
		reader.readAsDataURL(file);
	});
}
function QuizApp() {
	const [data, setData] = (0, import_react.useState)(() => freshData());
	const [round, setRound] = (0, import_react.useState)(null);
	const [screen, setScreen] = (0, import_react.useState)("home");
	const [teacher, setTeacher] = (0, import_react.useState)(false);
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	const [modal, setModal] = (0, import_react.useState)(null);
	const [tab, setTab] = (0, import_react.useState)("questions");
	const [notice, setNotice] = (0, import_react.useState)(null);
	const [pinInput, setPinInput] = (0, import_react.useState)("");
	const [pinError, setPinError] = (0, import_react.useState)("");
	const [confirm, setConfirm] = (0, import_react.useState)(null);
	const [qDraft, setQDraft] = (0, import_react.useState)(null);
	const [gDraft, setGDraft] = (0, import_react.useState)(null);
	const [brokenId, setBrokenId] = (0, import_react.useState)(null);
	const actions = (0, import_react.useRef)({
		next: () => {},
		prev: () => {},
		reveal: () => {}
	});
	const prevLeft = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const saved = load();
		setData(saved.data);
		setRound(saved.round);
		setTeacher(window.sessionStorage.getItem(TEACHER_KEY) === "1");
		setHydrated(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		if (!save({
			data,
			round
		})) setNotice("บันทึกไม่สำเร็จ พื้นที่ในเบราว์เซอร์เต็ม ลองลบรูปที่อัปโหลดขนาดใหญ่");
	}, [
		data,
		round,
		hydrated
	]);
	(0, import_react.useEffect)(() => {
		const onPointer = () => unlockAudio();
		window.addEventListener("pointerdown", onPointer);
		return () => window.removeEventListener("pointerdown", onPointer);
	}, []);
	(0, import_react.useEffect)(() => {
		if (screen !== "game" || !round?.running) return;
		const ends = Date.now() + round.timeLeft * 1e3;
		const id = window.setInterval(() => {
			const left = Math.max(0, Math.ceil((ends - Date.now()) / 1e3));
			setRound((current) => {
				if (!current?.running) return current;
				if (left <= 0) return {
					...current,
					timeLeft: 0,
					running: false
				};
				if (current.timeLeft === left) return current;
				return {
					...current,
					timeLeft: left
				};
			});
		}, 200);
		return () => window.clearInterval(id);
	}, [
		screen,
		round?.running,
		round?.index
	]);
	(0, import_react.useEffect)(() => {
		if (!round) return;
		const previous = prevLeft.current;
		prevLeft.current = round.timeLeft;
		if (previous !== null && previous > 0 && round.timeLeft === 0 && screen === "game") playCue("timeout", data.settings.sound);
	}, [
		round,
		screen,
		data.settings.sound
	]);
	const question = round ? data.questions.find((item) => item.id === round.order[round.index]) ?? null : null;
	const award = question && round ? round.awards[question.id] : void 0;
	const canResume = Boolean(round?.active && round.index < round.order.length);
	function goHome() {
		setRound((current) => current ? {
			...current,
			running: false
		} : current);
		setModal(null);
		setScreen("home");
	}
	function startGame(resetScores) {
		if (!data.questions.length) {
			setNotice("ยังไม่มีคำถาม เข้าโหมดครูเพื่อเพิ่มรูปและชื่ออาหาร");
			return;
		}
		playCue("start", data.settings.sound);
		const ids = data.questions.map((item) => item.id);
		setData((current) => resetScores ? {
			...current,
			groups: current.groups.map((group) => ({
				...group,
				score: 0
			}))
		} : current);
		setRound({
			order: data.settings.randomize ? shuffle(ids) : ids,
			index: 0,
			awards: {},
			revealed: false,
			timeLeft: data.settings.timer,
			running: true,
			active: true
		});
		setBrokenId(null);
		setScreen("game");
	}
	function resume() {
		if (!round?.active) return;
		const currentId = round.order[round.index];
		const already = Boolean(currentId && round.awards[currentId]);
		setRound({
			...round,
			running: round.timeLeft > 0 && !already && !round.revealed
		});
		setScreen("game");
	}
	function reveal() {
		setRound((current) => {
			if (!current) return current;
			const showing = !current.revealed;
			return {
				...current,
				revealed: showing,
				running: showing ? false : current.running
			};
		});
	}
	function next() {
		if (!round) return;
		const index = round.index + 1;
		if (index >= round.order.length) {
			setRound({
				...round,
				index,
				active: false,
				running: false,
				revealed: false
			});
			setScreen("result");
			return;
		}
		const id = round.order[index];
		const already = Boolean(round.awards[id]);
		setRound({
			...round,
			index,
			revealed: already,
			running: !already,
			timeLeft: data.settings.timer
		});
		setBrokenId(null);
	}
	function prev() {
		setRound((current) => {
			if (!current || current.index <= 0) return current;
			const index = current.index - 1;
			const id = current.order[index];
			const already = Boolean(current.awards[id]);
			return {
				...current,
				index,
				revealed: already,
				running: !already,
				timeLeft: data.settings.timer
			};
		});
		setBrokenId(null);
	}
	actions.current = {
		next,
		prev,
		reveal
	};
	(0, import_react.useEffect)(() => {
		function onKey(event) {
			if (event.key === "Escape") {
				setModal(null);
				setConfirm(null);
				setQDraft(null);
				setGDraft(null);
				return;
			}
			const target = event.target;
			if (Boolean(target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.isContentEditable)) || screen !== "game" || modal || confirm || qDraft || gDraft) return;
			if (event.key === "ArrowRight") {
				event.preventDefault();
				actions.current.next();
			} else if (event.key === "ArrowLeft") {
				event.preventDefault();
				actions.current.prev();
			} else if (event.key === " ") {
				event.preventDefault();
				actions.current.reveal();
			}
		}
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [
		screen,
		modal,
		confirm,
		qDraft,
		gDraft
	]);
	function givePoints(groupId) {
		if (!round || !question || round.awards[question.id]) return;
		const points = data.settings.pointsPerQ;
		const given = {
			groupId,
			points
		};
		setRound({
			...round,
			revealed: true,
			running: false,
			awards: {
				...round.awards,
				[question.id]: given
			}
		});
		setData((current) => ({
			...current,
			groups: current.groups.map((group) => group.id === groupId ? {
				...group,
				score: group.score + points
			} : group)
		}));
		playCue("correct", data.settings.sound);
	}
	function undoPoints() {
		if (!round || !question) return;
		const given = round.awards[question.id];
		if (!given) return;
		const awards = { ...round.awards };
		delete awards[question.id];
		setRound({
			...round,
			awards
		});
		setData((current) => ({
			...current,
			groups: current.groups.map((group) => group.id === given.groupId ? {
				...group,
				score: Math.max(0, group.score - given.points)
			} : group)
		}));
	}
	function toggleTimer() {
		setRound((current) => {
			if (!current || current.timeLeft <= 0) return current;
			return {
				...current,
				running: !current.running
			};
		});
	}
	function verifyPin() {
		if (pinInput === data.settings.pin) {
			setTeacher(true);
			window.sessionStorage.setItem(TEACHER_KEY, "1");
			setPinInput("");
			setPinError("");
			setModal(null);
			setScreen("teacher");
			return;
		}
		setPinError("รหัสไม่ถูกต้อง");
	}
	function logout() {
		window.sessionStorage.removeItem(TEACHER_KEY);
		setTeacher(false);
		setScreen("home");
	}
	function ask(nextConfirm) {
		setConfirm(nextConfirm);
	}
	const title = data.settings.gameTitle || "Food Picture Quiz";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		screen === "home" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Home, {
			title,
			canResume,
			onStart: () => startGame(false),
			onResetStart: () => ask({
				title: "เริ่มรอบใหม่และล้างคะแนน",
				body: "คะแนนทุกกลุ่มจะกลับเป็น 0 แล้วเริ่มข้อแรกใหม่",
				ok: "ล้างคะแนนแล้วเริ่ม",
				danger: true,
				run: () => startGame(true)
			}),
			onResume: resume,
			onGroups: () => setModal("groups"),
			onBoard: () => setModal("board"),
			onTeacher: () => {
				if (teacher) setScreen("teacher");
				else {
					setPinError("");
					setModal("pin");
				}
			}
		}) : null,
		screen === "game" && round ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Game, {
			title,
			round,
			question,
			groups: data.groups,
			award,
			points: data.settings.pointsPerQ,
			broken: brokenId === question?.id,
			onBroken: () => question && setBrokenId(question.id),
			onHome: goHome,
			onPrev: prev,
			onNext: next,
			onReveal: reveal,
			onToggleTimer: toggleTimer,
			onAward: givePoints,
			onUndo: undoPoints
		}) : null,
		screen === "result" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Result, {
			groups: data.groups,
			onAgain: () => startGame(false),
			onReset: () => startGame(true),
			onHome: goHome
		}) : null,
		screen === "teacher" && teacher ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Teacher, {
			data,
			tab,
			setTab,
			onLogout: logout,
			onQuestions: (questions) => setData((current) => ({
				...current,
				questions
			})),
			onGroups: (groups) => setData((current) => ({
				...current,
				groups
			})),
			onSettings: (settings) => setData((current) => ({
				...current,
				settings
			})),
			onReplace: (next) => {
				setData(next);
				setRound(null);
			},
			onReset: () => {
				setData(freshData());
				setRound(null);
				setNotice("คืนค่าเริ่มต้นแล้ว");
			},
			ask,
			openQuestion: setQDraft,
			openGroup: setGDraft,
			setNotice
		}) : null,
		modal === "pin" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
			title: "โหมดครู",
			onClose: () => setModal(null),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted",
				children: "ใช้สำหรับจัดการคำถาม กลุ่ม และคะแนนบนเครื่องนี้"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-4 grid gap-3",
				onSubmit: (event) => {
					event.preventDefault();
					verifyPin();
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "grid gap-1 font-semibold",
						htmlFor: "pin",
						children: ["รหัสครู", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "pin",
							className: "field",
							type: "password",
							autoFocus: true,
							value: pinInput,
							onChange: (event) => setPinInput(event.target.value)
						})]
					}),
					pinError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-chili",
						children: pinError
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn btn-chili",
						type: "submit",
						children: "เข้าสู่โหมดครู"
					})
				]
			})]
		}) : null,
		modal === "groups" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
			title: "กลุ่มผู้เล่น",
			onClose: () => setModal(null),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GroupList, { groups: data.groups })
		}) : null,
		modal === "board" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
			title: "ตารางคะแนน",
			onClose: () => setModal(null),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Board, { groups: data.groups })
		}) : null,
		qDraft ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuestionModal, {
			draft: qDraft,
			setDraft: setQDraft,
			onClose: () => setQDraft(null),
			onSave: () => {
				if (!qDraft.answer.trim() || !isSafeImage(qDraft.image)) {
					setNotice("ใส่ชื่ออาหารและรูปที่ใช้งานได้");
					return;
				}
				setData((current) => {
					const next = qDraft.id ? current.questions.map((item) => item.id === qDraft.id ? {
						...item,
						answer: qDraft.answer.trim(),
						alt: qDraft.alt.trim(),
						image: qDraft.image
					} : item) : [...current.questions, {
						id: uid("q"),
						answer: qDraft.answer.trim(),
						alt: qDraft.alt.trim(),
						image: qDraft.image
					}];
					return {
						...current,
						questions: next
					};
				});
				setQDraft(null);
			},
			setNotice
		}) : null,
		gDraft ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
			title: gDraft.id ? "แก้ไขกลุ่ม" : "เพิ่มกลุ่ม",
			onClose: () => setGDraft(null),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "grid gap-3",
				onSubmit: (event) => {
					event.preventDefault();
					const name = gDraft.name.trim();
					if (!name) return;
					setData((current) => ({
						...current,
						groups: gDraft.id ? current.groups.map((group) => group.id === gDraft.id ? {
							...group,
							name,
							color: gDraft.color
						} : group) : [...current.groups, {
							id: uid("g"),
							name,
							color: gDraft.color,
							score: 0
						}]
					}));
					setGDraft(null);
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "grid gap-1 font-semibold",
						children: ["ชื่อกลุ่ม", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							value: gDraft.name,
							onChange: (event) => setGDraft({
								...gDraft,
								name: event.target.value
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold",
							children: "สีกลุ่ม"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [SWATCHES.map((color) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": color,
								className: "size-11 rounded-full",
								style: {
									background: color,
									boxShadow: gDraft.color === color ? "0 0 0 3px #241c16" : "inset 0 0 0 1px #e3d6c6"
								},
								onClick: () => setGDraft({
									...gDraft,
									color
								})
							}, color)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								"aria-label": "เลือกสีเอง",
								className: "size-11",
								type: "color",
								value: gDraft.color,
								onChange: (event) => setGDraft({
									...gDraft,
									color: event.target.value
								})
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn btn-chili",
						type: "submit",
						children: "บันทึกกลุ่ม"
					})
				]
			})
		}) : null,
		confirm ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
			title: confirm.title,
			onClose: () => setConfirm(null),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: confirm.body }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "btn btn-line",
					type: "button",
					onClick: () => setConfirm(null),
					children: "ยกเลิก"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: confirm.danger ? "btn btn-chili" : "btn btn-ink",
					type: "button",
					onClick: () => {
						confirm.run();
						setConfirm(null);
					},
					children: confirm.ok
				})]
			})]
		}) : null,
		notice ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "fixed inset-x-0 bottom-4 z-50 mx-auto flex w-[min(92vw,32rem)] items-center justify-between gap-3 rounded-card bg-ink px-4 py-3 text-on-night shadow-lg",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: notice }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "btn btn-chili",
				type: "button",
				onClick: () => setNotice(null),
				children: "ปิด"
			})]
		}) : null
	] });
}
function Home({ title, canResume, onStart, onResetStart, onResume, onGroups, onBoard, onTeacher }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto grid min-h-dvh max-w-6xl items-center gap-8 px-4 py-8 md:grid-cols-2 md:px-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-semibold text-chili",
				children: "เกมห้องเรียน"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-5xl leading-none text-ink md:text-6xl",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 max-w-md text-lg text-muted",
				children: "เปิดภาพอาหารบนจอ ให้นักเรียนทายชื่อ แล้วให้คะแนนกลุ่มที่ได้คำตอบ"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid max-w-sm gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: "btn btn-chili",
						type: "button",
						onClick: onStart,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
							className: "size-5",
							"aria-hidden": "true"
						}), " เริ่มเกม"]
					}),
					canResume ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn btn-ink",
						type: "button",
						onClick: onResume,
						children: "เล่นต่อจากข้อที่ค้าง"
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: "btn btn-line",
						type: "button",
						onClick: onGroups,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, {
							className: "size-5",
							"aria-hidden": "true"
						}), " กลุ่มผู้เล่น"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: "btn btn-line",
						type: "button",
						onClick: onBoard,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trophy, {
							className: "size-5",
							"aria-hidden": "true"
						}), " ตารางคะแนน"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: "btn btn-line",
						type: "button",
						onClick: onResetStart,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {
							className: "size-5",
							"aria-hidden": "true"
						}), " เริ่มใหม่และล้างคะแนน"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: "btn btn-line",
						type: "button",
						onClick: onTeacher,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, {
							className: "size-5",
							"aria-hidden": "true"
						}), " โหมดครู"]
					})
				]
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "grid grid-cols-2 gap-3",
			"aria-hidden": "true",
			children: [
				"/food/tom-yum.jpg",
				"/food/pad-thai.jpg",
				"/food/mango-sticky.jpg",
				"/food/sushi.jpg"
			].map((src) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src,
				alt: "",
				className: "aspect-square w-full rounded-card object-cover"
			}, src))
		})]
	});
}
function Game({ title, round, question, groups, award, points, broken, onBroken, onHome, onPrev, onNext, onReveal, onToggleTimer, onAward, onUndo }) {
	const awardedGroup = award ? groups.find((group) => group.id === award.groupId) : void 0;
	const hot = round.timeLeft <= 5;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-dvh flex-col gap-3 p-3 md:h-dvh md:overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-wrap items-center gap-3 rounded-card bg-surface px-3 py-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: "btn btn-line",
						type: "button",
						onClick: onHome,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(House, {
							className: "size-5",
							"aria-hidden": "true"
						}), " หน้าแรก"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-display text-xl",
						children: [
							"ข้อ ",
							Math.min(round.index + 1, round.order.length),
							"/",
							round.order.length
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "min-w-0 flex-1 truncate text-center font-display text-2xl",
						children: title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: `btn ${hot ? "btn-chili timer-hot" : "btn-line"}`,
						type: "button",
						onClick: onToggleTimer,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Timer, {
								className: "size-5",
								"aria-hidden": "true"
							}),
							round.timeLeft,
							" วิ",
							round.running ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, {
								className: "size-4",
								"aria-hidden": "true"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
								className: "size-4",
								"aria-hidden": "true"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn btn-line",
						type: "button",
						"aria-label": "เต็มหน้าจอ",
						onClick: () => {
							if (!document.fullscreenElement) document.documentElement.requestFullscreen().catch(() => {});
							else document.exitFullscreen?.();
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Maximize2, {
							className: "size-5",
							"aria-hidden": "true"
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative min-h-72 flex-1 overflow-hidden rounded-card bg-night",
				children: [question && !broken ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: question.image,
					alt: "ภาพอาหารสำหรับทาย",
					className: "h-full w-full object-contain",
					onError: onBroken
				}, question.id) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid h-full place-items-center px-6 text-center text-on-night",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-3xl",
						children: question ? "โหลดภาพนี้ไม่ได้" : "คำถามข้อนี้ไม่มีแล้ว"
					})
				}), round.revealed && question ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute inset-x-0 bottom-0 bg-leaf px-4 py-3 text-center text-on-leaf",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-4xl leading-none",
						children: question.answer
					}), question.alt ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1",
						children: ["รับคำตอบสำรอง: ", question.alt]
					}) : null]
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-card bg-surface p-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex flex-wrap items-center justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						"กลุ่มที่ได้คะแนนข้อนี้:",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
							style: { color: awardedGroup?.color },
							children: awardedGroup ? `${awardedGroup.name} (+${award?.points})` : "ยังไม่ได้ให้"
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								className: "btn btn-line",
								type: "button",
								onClick: onPrev,
								disabled: round.index === 0,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, {
									className: "size-5",
									"aria-hidden": "true"
								}), " ก่อนหน้า"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								className: "btn btn-ink",
								type: "button",
								onClick: onReveal,
								children: [round.revealed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, {
									className: "size-5",
									"aria-hidden": "true"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, {
									className: "size-5",
									"aria-hidden": "true"
								}), round.revealed ? "ซ่อนเฉลย" : "เฉลย"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								className: "btn btn-chili",
								type: "button",
								onClick: onNext,
								children: [round.index + 1 >= round.order.length ? "สรุปผล" : "ข้อถัดไป", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {
									className: "size-5",
									"aria-hidden": "true"
								})]
							})
						]
					})]
				}), round.revealed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-2 sm:grid-cols-2",
					children: groups.length ? groups.map((group) => {
						const selected = award?.groupId === group.id;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn h-auto whitespace-normal px-3 py-2 text-center",
							disabled: Boolean(award) && !selected,
							style: {
								background: group.color,
								color: inkOn(group.color)
							},
							onClick: () => selected ? onUndo() : onAward(group.id),
							children: selected ? `ยกเลิกคะแนน ${group.name}` : `${group.name} +${points}`
						}, group.id);
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-muted",
						children: "ยังไม่มีกลุ่ม เพิ่มได้ในโหมดครู"
					})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "ลูกศรซ้าย/ขวาเปลี่ยนข้อ · Space เฉลย · กดเวลาเพื่อหยุดนาฬิกา"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "flex gap-2 overflow-x-auto pb-1",
				children: groups.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-w-36 items-center justify-between gap-3 rounded-2xl bg-surface px-3 py-2",
					style: { boxShadow: `inset 4px 0 0 ${group.color}` },
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "truncate font-semibold",
						children: group.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: group.score })]
				}, group.id))
			})
		]
	});
}
function Result({ groups, onAgain, onReset, onHome }) {
	const rows = ranked(groups);
	const slots = [
		rows[1],
		rows[0],
		rows[2]
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-dvh flex-col items-center bg-night px-4 py-8 text-on-night",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Medal, {
				className: "size-10 text-gold",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-5xl",
				children: "สรุปผล"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 flex items-end justify-center gap-3",
				children: slots.map((group, index) => group ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: `grid w-28 place-items-end rounded-t-card px-2 py-3 text-center text-ink sm:w-36 ${index === 1 ? "h-44 bg-gold" : index === 0 ? "h-32 bg-line" : "h-24 bg-chili-soft"}`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm",
							children: ["อันดับ ", group.rank]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-xl leading-tight",
							children: group.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-semibold",
							children: group.score
						})
					] })
				}, group.id) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-28 sm:w-36" }, index))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-8 w-full max-w-lg",
				children: rows.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center gap-3 border-b border-line/30 py-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-8 font-display text-2xl",
							children: group.rank
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "size-3 rounded-full",
							style: { background: group.color }
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex-1",
							children: group.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-semibold",
							children: [group.score, " คะแนน"]
						})
					]
				}, group.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 flex flex-wrap justify-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn btn-chili",
						type: "button",
						onClick: onAgain,
						children: "เล่นอีกรอบ (เก็บคะแนน)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn btn-gold",
						type: "button",
						onClick: onReset,
						children: "ล้างคะแนนแล้วเล่นใหม่"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn btn-line",
						type: "button",
						onClick: onHome,
						children: "หน้าแรก"
					})
				]
			})
		]
	});
}
function Teacher({ data, tab, setTab, onLogout, onQuestions, onGroups, onSettings, onReplace, onReset, ask, openQuestion, openGroup, setNotice }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "min-h-dvh bg-paper",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "flex items-center justify-between gap-3 border-b border-line bg-surface px-4 py-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl",
				children: "โหมดครู"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "btn btn-chili",
				type: "button",
				onClick: onLogout,
				children: "ออกจากโหมดครู"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "md:grid md:grid-cols-[14rem_1fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "flex gap-2 overflow-x-auto border-b border-line bg-surface p-2 md:flex-col md:border-r md:border-b-0",
				children: [
					{
						id: "questions",
						label: "คำถาม",
						icon: UtensilsCrossed
					},
					{
						id: "groups",
						label: "กลุ่ม",
						icon: Users
					},
					{
						id: "scores",
						label: "คะแนน",
						icon: Trophy
					},
					{
						id: "settings",
						label: "ตั้งค่า",
						icon: SlidersHorizontal
					},
					{
						id: "data",
						label: "ข้อมูล",
						icon: Database
					}
				].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: `btn justify-start ${tab === item.id ? "btn-ink" : "btn-line"}`,
					onClick: () => setTab(item.id),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, {
							className: "size-5",
							"aria-hidden": "true"
						}),
						" ",
						item.label
					]
				}, item.id))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "p-4",
				children: [
					tab === "questions" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: "btn btn-chili",
						type: "button",
						onClick: () => openQuestion({
							id: null,
							answer: "",
							alt: "",
							image: ""
						}),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
							className: "size-5",
							"aria-hidden": "true"
						}), " เพิ่มคำถาม"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 overflow-x-auto rounded-card bg-surface",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full min-w-[40rem] text-left",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
								className: "text-muted",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "p-3",
										children: "ข้อ"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "p-3",
										children: "ภาพ"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "p-3",
										children: "เฉลย"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "p-3",
										children: "สำรอง"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "p-3",
										children: "จัดการ"
									})
								] })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: data.questions.map((question, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-t border-line",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "p-3",
										children: index + 1
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "p-3",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
											src: question.image,
											alt: "",
											className: "h-14 w-20 rounded-xl bg-paper object-contain"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "p-3 font-semibold",
										children: question.answer
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "p-3 text-muted",
										children: question.alt || "-"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "p-3",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex flex-wrap gap-1",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
													label: "เลื่อนขึ้น",
													onClick: () => move(data.questions, index, -1, onQuestions),
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronUp, { className: "size-4" })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
													label: "เลื่อนลง",
													onClick: () => move(data.questions, index, 1, onQuestions),
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-4" })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
													label: "แก้ไข",
													onClick: () => openQuestion({
														id: question.id,
														answer: question.answer,
														alt: question.alt,
														image: question.image
													}),
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-4" })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
													label: "ลบ",
													onClick: () => ask({
														title: "ลบคำถาม",
														body: `ลบ “${question.answer}” ออกจากชุดคำถาม`,
														ok: "ลบ",
														danger: true,
														run: () => onQuestions(data.questions.filter((item) => item.id !== question.id))
													}),
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
												})
											]
										})
									})
								]
							}, question.id)) })]
						})
					})] }) : null,
					tab === "groups" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: "btn btn-chili",
						type: "button",
						onClick: () => openGroup({
							id: null,
							name: "",
							color: SWATCHES[data.groups.length % SWATCHES.length]
						}),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
							className: "size-5",
							"aria-hidden": "true"
						}), " เพิ่มกลุ่ม"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 grid gap-2",
						children: data.groups.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center gap-3 rounded-card bg-surface p-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "size-6 rounded-full",
									style: { background: group.color }
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "flex-1 font-semibold",
									children: group.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [group.score, " คะแนน"] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
									label: "แก้ไขกลุ่ม",
									onClick: () => openGroup({
										id: group.id,
										name: group.name,
										color: group.color
									}),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
									label: "ลบกลุ่ม",
									onClick: () => ask({
										title: "ลบกลุ่ม",
										body: `ลบ ${group.name} และคะแนนของกลุ่มนี้`,
										ok: "ลบ",
										danger: true,
										run: () => onGroups(data.groups.filter((item) => item.id !== group.id))
									}),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
								})
							]
						}, group.id))
					})] }) : null,
					tab === "scores" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							className: "btn btn-chili w-fit",
							type: "button",
							onClick: () => ask({
								title: "รีเซ็ตคะแนน",
								body: "คะแนนทุกกลุ่มจะเป็น 0 แต่คำถามและชื่อกลุ่มยังอยู่",
								ok: "รีเซ็ต",
								danger: true,
								run: () => onGroups(data.groups.map((group) => ({
									...group,
									score: 0
								})))
							}),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {
								className: "size-5",
								"aria-hidden": "true"
							}), " รีเซ็ตคะแนนทั้งหมด"]
						}), data.groups.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-2 rounded-card bg-surface p-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "size-4 rounded-full",
									style: { background: group.color }
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "flex-1",
									children: group.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "w-16 text-right font-display text-2xl",
									children: group.score
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									className: "btn btn-leaf",
									type: "button",
									onClick: () => bump(group.id, data.settings.pointsPerQ, data.groups, onGroups),
									children: ["+", data.settings.pointsPerQ]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									className: "btn btn-line",
									type: "button",
									onClick: () => bump(group.id, -data.settings.pointsPerQ, data.groups, onGroups),
									children: ["-", data.settings.pointsPerQ]
								})
							]
						}, group.id))]
					}) : null,
					tab === "settings" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsForm, {
						settings: data.settings,
						onSave: onSettings,
						setNotice
					}) : null,
					tab === "data" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTools, {
						data,
						onReplace,
						onReset: () => ask({
							title: "คืนค่าเริ่มต้น",
							body: "คำถาม กลุ่ม คะแนน และการตั้งค่าจะกลับเป็นชุดอาหาร 20 ข้อ รหัสครูกลับเป็นค่าเดิม",
							ok: "คืนค่า",
							danger: true,
							run: onReset
						}),
						setNotice
					}) : null
				]
			})]
		})]
	});
}
function SettingsForm({ settings, onSave, setNotice }) {
	const [draft, setDraft] = (0, import_react.useState)(settings);
	(0, import_react.useEffect)(() => setDraft(settings), [settings]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "grid max-w-lg gap-3",
		onSubmit: (event) => {
			event.preventDefault();
			const timer = Number(draft.timer);
			const points = Number(draft.pointsPerQ);
			if (!draft.gameTitle.trim() || !draft.pin.trim() || draft.pin.trim().length < 4) {
				setNotice("ตั้งชื่อเกมและรหัสครูอย่างน้อย 4 ตัว");
				return;
			}
			if (!Number.isFinite(timer) || timer < 5 || timer > 3600 || !Number.isFinite(points) || points < 0) {
				setNotice("เวลาต้องอยู่ระหว่าง 5–3600 วินาที และคะแนนต้องไม่ติดลบ");
				return;
			}
			onSave({
				...draft,
				gameTitle: draft.gameTitle.trim(),
				pin: draft.pin.trim(),
				timer: Math.round(timer),
				pointsPerQ: Math.round(points)
			});
			setNotice("บันทึกการตั้งค่าแล้ว");
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "grid gap-1 font-semibold",
				children: ["ชื่อเกม", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "field",
					value: draft.gameTitle,
					onChange: (event) => setDraft({
						...draft,
						gameTitle: event.target.value
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "grid gap-1 font-semibold",
				children: ["เวลาต่อข้อ (วินาที)", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "field",
					type: "number",
					min: 5,
					max: 3600,
					value: draft.timer,
					onChange: (event) => setDraft({
						...draft,
						timer: Number(event.target.value)
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "grid gap-1 font-semibold",
				children: ["คะแนนต่อข้อ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "field",
					type: "number",
					min: 0,
					value: draft.pointsPerQ,
					onChange: (event) => setDraft({
						...draft,
						pointsPerQ: Number(event.target.value)
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "grid gap-1 font-semibold",
				children: ["รหัสครู", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "field",
					value: draft.pin,
					onChange: (event) => setDraft({
						...draft,
						pin: event.target.value
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					checked: draft.randomize,
					onChange: (event) => setDraft({
						...draft,
						randomize: event.target.checked
					})
				}), "สุ่มลำดับคำถามเมื่อเริ่มเกม"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: draft.sound,
						onChange: (event) => setDraft({
							...draft,
							sound: event.target.checked
						})
					}),
					draft.sound ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, {
						className: "size-5",
						"aria-hidden": "true"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, {
						className: "size-5",
						"aria-hidden": "true"
					}),
					"เสียงเอฟเฟกต์"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "btn btn-chili w-fit",
				type: "submit",
				children: "บันทึกการตั้งค่า"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					"รหัสเริ่มต้นคือ ",
					DEFAULT_PIN,
					" เปลี่ยนได้จากช่องด้านบน"
				]
			})
		]
	});
}
function DataTools({ data, onReplace, onReset, setNotice }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid max-w-lg gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted",
				children: "สำรองคำถาม กลุ่ม และคะแนนเป็นไฟล์ แล้วนำเข้าบนเครื่องอื่นได้"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				className: "btn btn-ink w-fit",
				type: "button",
				onClick: () => {
					const blob = new Blob([JSON.stringify({ data }, null, 2)], { type: "application/json" });
					const url = URL.createObjectURL(blob);
					const link = document.createElement("a");
					link.href = url;
					link.download = "food-picture-quiz.json";
					link.click();
					URL.revokeObjectURL(url);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
					className: "size-5",
					"aria-hidden": "true"
				}), " ส่งออก JSON"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "btn btn-line w-fit",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, {
						className: "size-5",
						"aria-hidden": "true"
					}),
					" นำเข้า JSON",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "sr-only",
						type: "file",
						accept: "application/json,.json",
						onChange: (event) => {
							const file = event.target.files?.[0];
							event.target.value = "";
							if (!file) return;
							const reader = new FileReader();
							reader.onload = () => {
								try {
									const next = importPayload(JSON.parse(String(reader.result)));
									if (!next) {
										setNotice("ไฟล์นี้ไม่มีคำถามหรือกลุ่มที่ใช้งานได้");
										return;
									}
									onReplace(next);
									setNotice("นำเข้าข้อมูลแล้ว");
								} catch {
									setNotice("อ่านไฟล์ JSON ไม่ได้");
								}
							};
							reader.readAsText(file);
						}
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				className: "btn btn-chili w-fit",
				type: "button",
				onClick: onReset,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {
					className: "size-5",
					"aria-hidden": "true"
				}), " คืนค่าเริ่มต้นทั้งหมด"]
			})
		]
	});
}
function QuestionModal({ draft, setDraft, onClose, onSave, setNotice }) {
	const preview = draft.image;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		title: draft.id ? "แก้ไขคำถาม" : "เพิ่มคำถาม",
		onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "grid gap-3",
			onSubmit: (event) => {
				event.preventDefault();
				onSave();
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "grid gap-1 font-semibold",
					children: ["ชื่ออาหาร", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						value: draft.answer,
						onChange: (event) => setDraft({
							...draft,
							answer: event.target.value
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "grid gap-1 font-semibold",
					children: ["คำตอบสำรอง คั่นด้วยจุลภาค", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						value: draft.alt,
						onChange: (event) => setDraft({
							...draft,
							alt: event.target.value
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "grid gap-1 font-semibold",
					children: ["อัปโหลดรูป", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						type: "file",
						accept: "image/*",
						onChange: (event) => {
							const file = event.target.files?.[0];
							if (!file) return;
							compressImage(file).then((image) => setDraft({
								...draft,
								image
							})).catch((error) => setNotice(error.message));
						}
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "grid gap-1 font-semibold",
					children: ["หรือวางลิงก์รูป", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						value: draft.image.startsWith("data:") ? "" : draft.image,
						placeholder: "https://",
						onChange: (event) => setDraft({
							...draft,
							image: event.target.value.trim()
						})
					})]
				}),
				preview ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: preview,
					alt: "",
					className: "max-h-40 rounded-card object-contain"
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "btn btn-chili",
					type: "submit",
					children: "บันทึกคำถาม"
				})
			]
		})
	});
}
function Modal({ title, onClose, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-40 grid place-items-center bg-ink/50 p-4",
		role: "presentation",
		onClick: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-modal": "true",
			"aria-label": title,
			className: "max-h-[90dvh] w-full max-w-lg overflow-y-auto rounded-card bg-surface p-5",
			onClick: (event) => event.stopPropagation(),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-3xl",
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "btn btn-line",
					type: "button",
					onClick: onClose,
					children: "ปิด"
				})]
			}), children]
		})
	});
}
function GroupList({ groups }) {
	if (!groups.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "ยังไม่มีกลุ่ม" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "grid gap-2",
		children: groups.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "flex items-center gap-3 rounded-2xl border border-line px-3 py-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "size-4 rounded-full",
					style: { background: group.color }
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
					className: "flex-1",
					children: group.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [group.score, " คะแนน"] })
			]
		}, group.id))
	});
}
function Board({ groups }) {
	const rows = ranked(groups);
	if (!rows.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "ยังไม่มีคะแนน" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", { children: rows.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "flex items-center gap-3 border-b border-line py-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "w-8 font-display text-2xl",
				children: group.rank
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "flex-1",
				children: group.name
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-semibold",
				children: group.score
			})
		]
	}, group.id)) });
}
function IconButton({ label, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		className: "btn btn-line px-3",
		type: "button",
		"aria-label": label,
		onClick,
		children
	});
}
function move(list, index, dir, commit) {
	const next = [...list];
	const target = index + dir;
	if (target < 0 || target >= next.length) return;
	[next[index], next[target]] = [next[target], next[index]];
	commit(next);
}
function bump(id, amount, groups, commit) {
	commit(groups.map((group) => group.id === id ? {
		...group,
		score: Math.max(0, group.score + amount)
	} : group));
}
var SplitComponent = QuizApp;
//#endregion
export { SplitComponent as component };
