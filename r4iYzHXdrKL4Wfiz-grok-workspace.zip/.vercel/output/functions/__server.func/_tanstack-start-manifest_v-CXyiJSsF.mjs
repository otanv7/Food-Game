//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CXyiJSsF.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CgjoFJAq.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CgjoFJAq.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-8BEcCKZx.js"]
	}
} });
//#endregion
export { tsrStartManifest };
